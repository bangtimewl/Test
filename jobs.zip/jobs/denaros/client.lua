local CurrentPlayerJob = {job = nil, grade = nil}
local JobData = Config.Jobs.Denaros
local ClockedIn = false
local OvenStatus = {baking = false, type = nil, fire = false, timer = 0}
local AllowInteraction = true
local ActiveFire = nil

local TrashCount = 0
local TrashActive = false
local Trashbag = nil

function GetDenaros(type)
    for i=1, #JobData.CookableItems do 
        if (type == JobData.CookableItems[i].Name) then 
            return JobData.CookableItems[i]
        end
    end
end

function DenarosGetDenarossMenu()
    local menu = {
        {
            id = 1,
            header = "Bake Denaros",
            txt = "This is where you can bake any denaros. Don't forget the ingredients first!"
        },
    }
    for i=1, #JobData.CookableItems do 
        local data = JobData.CookableItems
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "bake_denaros",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function DenarosGetDrinksMenu()
    local menu = {
        {
            id = 1,
            header = "Drink Fountain",
            txt = "This is where you can pour any drinks for a fee."
        },
    }
    for i=1, #JobData.Drinks do 
        local data = JobData.Drinks
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "denaros_drink",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function DenarosGetIngredientsMenu()
    local menu = {
        {
            id = 1,
            header = "Denaros Ingredients",
            txt = "This is where you can grab any ingredients for your denaros. Don't forget the cheese and sauce!"
        },
    }
    for i=1, #JobData.Ingredients do 
        local data = JobData.Ingredients
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label .. " - $" .. data[i].Price,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "denaros_ingredients",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function DenarosGatherAnim()
    LoadAnim('mini@repair') 
    TaskPlayAnim(PlayerPedId(), 'mini@repair', 'fixing_a_player', 8.0, -8, -1, 49, 0, 0, 0, 0)
end

function DenarosStartFire(coords) 
    -- Make some variables for the particle dictionary and particle name.
    local dict = "scr_trevor3"
    local particleName = "scr_trev3_trailer_plume"

    -- Create a new thread.
    Citizen.CreateThread(function()
        -- Request the particle dictionary.
        RequestNamedPtfxAsset(dict)
        -- Wait for the particle dictionary to load.
        while not HasNamedPtfxAssetLoaded(dict) do
            Citizen.Wait(0)
        end
        UseParticleFxAssetNextCall(dict)
        -- Create a new non-looped particle effect, we don't need to store the particle handle because it will
        -- automatically get destroyed once the particle has finished it's animation (it's non-looped).
        ActiveFire = StartParticleFxLoopedAtCoord(particleName, coords.x, coords.y, coords.z, 0.0, 0.0, 0.0, 0.2, false, false, false)
    end)
end

function DenarosStopFire() 
    Citizen.CreateThread(function()
        AllowInteraction = false
        DisplayProgress(5000, "Extinguishing Fire", 'mini@repair', 'fixing_a_player')
        DenarosGatherAnim()
        Citizen.SetTimeout(5000, function()
            ClearPedTasksImmediately(PlayerPedId())
            StopParticleFxLooped(ActiveFire, true)
            ActiveFire = false
            AllowInteraction = true
        end)
    end)
end

function DenarosStartBaking(type)
    if (not OvenStatus.baking and OvenStatus.type == nil) then 
        OvenStatus.baking = true
        OvenStatus.type = type
        OvenStatus.timer = JobData.DenarosCookTime
        Citizen.CreateThread(function() 
            while OvenStatus.type ~= nil do
                OvenStatus.timer = OvenStatus.timer - 1
                if (OvenStatus.timer == 0) then
                    OvenStatus.baking = false
                end 
                if (OvenStatus.timer <= -JobData.OvercookedTime) then
                    OvenStatus.baking = false
                    OvenStatus.type = nil
                    OvenStatus.timer = 0
                    OvenStatus.fire = true
                    DenarosStartFire(JobData.InteractMarkers["denaros_oven"].Coords) 
                    break
                end 
                Citizen.Wait(1000)
            end
        end)
    end
end

function DenarosMakeDough()
    Citizen.CreateThread(function()
        AllowInteraction = false
        DisplayProgress(5000, "Making Denaros Dough", 'mini@repair', 'fixing_a_player')
        DenarosGatherAnim()
        Citizen.Wait(5000)
        ClearPedTasksImmediately(PlayerPedId())
        TriggerServerEvent("esx_societyjobs:denaros:craftDough")
        AllowInteraction = true
    end)
end

function DenarosPickupTrash() 
    if (TrashActive) then 
        return
    end
    TrashActive = true
    SetCurrentPedWeapon(GetPlayerPed(-1), 0xA2719263, true)
	RequestAnimDict("anim@amb@clubhouse@tutorial@bkr_tut_ig3@")
	while not HasAnimDictLoaded("anim@amb@clubhouse@tutorial@bkr_tut_ig3@") do
		Citizen.Wait(10)
	end
	TaskPlayAnim(PlayerPedId(), "anim@amb@clubhouse@tutorial@bkr_tut_ig3@", "machinic_loop_mechandplayer", 2.0, 2.0, 4000, 30, 0, 0, 0, 0)
	
	Citizen.Wait(4000)

	hasBag = true
	
	local pos = GetEntityCoords(GetPlayerPed(-1), true)
	TaskPlayAnim(PlayerPedId(), 'anim@heists@narcotics@trash', 'walk', 1.0, -1.0,-1,49,0,0, 0,0)
	local model = GetHashKey("hei_prop_heist_binbag")
	RequestModel(model)
	while not HasModelLoaded(model) do Citizen.Wait(0) end
	local object = CreateObject(model, pos.x, pos.y, pos.z, true, true, true)
	AttachEntityToEntity(object, GetPlayerPed(-1), GetPedBoneIndex(GetPlayerPed(-1), 57005), 0.12, 0.0, 0.00, 25.0, 270.0, 180.0, true, true, false, true, 1, true)
	Trashbag = object
end

function DenarosDisposeTrash() 
    TrashActive = false
    if not HasAnimDictLoaded("anim@heists@narcotics@trash") then
		RequestAnimDict("anim@heists@narcotics@trash") 
		while not HasAnimDictLoaded("anim@heists@narcotics@trash") do 
			Citizen.Wait(0)
		end
	end
	ClearPedTasksImmediately(GetPlayerPed(-1))
	TaskPlayAnim(PlayerPedId(), 'anim@heists@narcotics@trash', 'throw_b', 1.0, -1.0,-1,2,0,0, 0,0)
	Citizen.Wait(800)
    ClearPedTasks(GetPlayerPed(-1))
    DetachEntity(Trashbag, true, true)
    DeleteObject(Trashbag)
    Trashbag = nil
    TriggerServerEvent("esx_societyjobs:denaros:disposedTrash")
end

function DenarosToggleDuty(bool)
    ClockedIn = bool
    if (ClockedIn) then 
        DenarosSetMarkerDisplay("wash_hands", false)
        DenarosSetMarkerDisplay("clock_out", true)
        DenarosSetMarkerDisplay("boss", true)
        DenarosSetMarkerDisplay("drink_fountain", true)
        DenarosSetMarkerDisplay("drink_fountain2", true)		
        DenarosSetMarkerDisplay("denaros_ingredients", true)
        DenarosSetMarkerDisplay("denaros_oven", true)
        DenarosSetMarkerDisplay("trash_can", false)
        DenarosSetMarkerDisplay("dumpster", false)
    else
        DenarosSetMarkerDisplay("wash_hands", true)
        DenarosSetMarkerDisplay("clock_out", false)
        DenarosSetMarkerDisplay("boss", false)
        DenarosSetMarkerDisplay("drink_fountain", false)
        DenarosSetMarkerDisplay("drink_fountain2", true)		
        DenarosSetMarkerDisplay("denaros_ingredients", false)
        DenarosSetMarkerDisplay("denaros_oven", false)
        DenarosSetMarkerDisplay("trash_can", false)
        DenarosSetMarkerDisplay("dumpster", false)
    end
end

function DenarosSetMarkerDisplay(key, bool)
    JobData.InteractMarkers[key].Display = bool
end

function DenarosGetMarkerText(key)
    local text = JobData.InteractMarkers[key].DisplayText
    if (key == "denaros_oven") then 
        if OvenStatus.baking then 
            text = text:gsub("|oven_status|", "Baking Timer: " .. OvenStatus.timer .. " second(s)")
        elseif OvenStatus.type ~= nil then
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to take out the ".. GetDenaros(OvenStatus.type).Label ..".")
        elseif OvenStatus.fire then
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to extinguish the fire.")
        else
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to bake food.")
        end
    elseif (key == "trash_can") then
        text = text:gsub("|trash_status|", "Press ~INPUT_CONTEXT~ to take out the trash.")
    end
    return text
end

function DenarosInteractMarker(key)
    AllowInteraction = false
    local marker = JobData.InteractMarkers[key]
    if (key == "boss") then 
        OpenSocietyJobBossMenu()
    elseif (key == "clock_out") then 
        DenarosToggleDuty(false)
    elseif (key == "wash_hands") then 
        Citizen.CreateThread(function()
            AllowInteraction = false
            DisplayProgress(5000, "Washing Hands", 'mini@repair', 'fixing_a_player')
            DenarosGatherAnim()
            Citizen.Wait(5000)
            ClearPedTasksImmediately(PlayerPedId())
            DenarosToggleDuty(true)
            AllowInteraction = true
        end)
    elseif (key == "drink_fountain") then 
        TriggerEvent('nh-context-bridge:sendMenu', DenarosGetDrinksMenu())
    elseif (key == "drink_fountain2") then 
        TriggerEvent('nh-context-bridge:sendMenu', DenarosGetDrinksMenu())		
    elseif (key == "denaros_ingredients") then 
        TriggerEvent('nh-context-bridge:sendMenu', DenarosGetIngredientsMenu())
    elseif (key == "denaros_oven") then 
        if (OvenStatus.fire) then
            OvenStatus.fire = false
            DenarosStopFire() 
        elseif (not OvenStatus.baking and OvenStatus.type ~= nil) then 
            local denarosType = OvenStatus.type
            OvenStatus.type = nil
            OvenStatus.timer = 0
            OvenStatus.fire = false
            Citizen.CreateThread(function()
                AllowInteraction = false
                DisplayProgress(5000, "Taking Denaros out of Oven", 'mini@repair', 'fixing_a_player')
                DenarosGatherAnim()
                Citizen.Wait(5000)
                ClearPedTasksImmediately(PlayerPedId())
                TriggerServerEvent("esx_societyjobs:denaros:cookedDenaros", denarosType)
                AllowInteraction = true
            end)
        elseif (not OvenStatus.baking and OvenStatus.type == nil) then
            TriggerEvent('nh-context-bridge:sendMenu', DenarosGetDenarossMenu())
        end
    elseif (key == "trash_can") then
        DenarosPickupTrash()
    elseif (key == "dumpster") then
        DenarosDisposeTrash()
    end
    AllowInteraction = true
end

function DenarosThread()
    Citizen.CreateThread(function()
        while true do
            local wait = 1000
            local coords = GetPlayerCoords()
            for k,v in pairs(JobData.InteractMarkers) do 
                if (v.Display or v.Display == nil) then 
                    local dist = #(v.Coords - coords)
                    if (dist < 20.0) then 
                        wait = 0
                        if (Marker(v.Coords, dist, DenarosGetMarkerText(k)) and AllowInteraction) then 
                            DenarosInteractMarker(k)
                        end
                    end
                end
            end
            Citizen.Wait(wait)
        end
    end)
end

RegisterNetEvent("nh-context:returnData")
AddEventHandler("nh-context:returnData", function(_data)
    local key = _data.id
    local data = _data.data
    if (key == "denaros_ingredients") then 
        Citizen.CreateThread(function()
            ESX.TriggerServerCallback("esx_societyjobs:denaros:purchaseIngredient", function(result, trashTime) 
                if (result) then 
                    Citizen.CreateThread(function()
                        AllowInteraction = false
                        DisplayProgress(2000, "Grabbing Ingredient", 'mini@repair', 'fixing_a_player')
                        DenarosGatherAnim()
                        Citizen.Wait(2000)
                        ClearPedTasksImmediately(PlayerPedId())
                        AllowInteraction = true
                    end)
                elseif (trashTime) then
                    ESX.ShowNotification("You need to take out the trash first to get more ingredients.")
                else
                    ESX.ShowNotification("You cannot afford this ingredient.")
                end
            end, data.selected)
        end)
    elseif (key == "bake_denaros") then
        AllowInteraction = false
        ESX.TriggerServerCallback("esx_societyjobs:denaros:bakeDenaros", function(result) 
            if (result) then 
                Citizen.CreateThread(function()
                    DisplayProgress(5000, "Putting Denaros into Oven", 'mini@repair', 'fixing_a_player')
                    DenarosGatherAnim()
                    Citizen.Wait(5000)
                    ClearPedTasksImmediately(PlayerPedId())
                    DenarosStartBaking(result)
                    AllowInteraction = true
                end)
            else
                ESX.ShowNotification("Missing Ingredients for the Denaros.")
                AllowInteraction = true
            end
        end, data.selected)
    elseif (key == "denaros_drink") then
        AllowInteraction = false
        ESX.TriggerServerCallback("esx_societyjobs:denaros:getDrink", function(result) 
            if (result) then 
                Citizen.CreateThread(function()
                    DisplayProgress(5000, "Pouring Drink", 'mini@repair', 'fixing_a_player')
                    DenarosGatherAnim()
                    Citizen.Wait(5000)
                    ClearPedTasksImmediately(PlayerPedId())
                    AllowInteraction = true
                end)
            else
                ESX.ShowNotification("You cannot afford the drink.")
                AllowInteraction = true
            end
        end, data.selected)
    end
end)

RegisterNetEvent("esx_societyjobs:denaros:updateTrashcount")
AddEventHandler("esx_societyjobs:denaros:updateTrashcount", function(count)
    TrashCount = count
    if (TrashCount >= 3) then 
        DenarosSetMarkerDisplay("trash_can", true)
        DenarosSetMarkerDisplay("dumpster", true)
    else
        DenarosSetMarkerDisplay("trash_can", false)
        DenarosSetMarkerDisplay("dumpster", true)
    end
end)

RegisterNetEvent('esx_societyjobs:jobUpdated')
AddEventHandler('esx_societyjobs:jobUpdated', function(job)
    if (not CurrentPlayerJob.job or (CurrentPlayerJob.job ~= job.name or CurrentPlayerJob.grade ~= job.grade)) then 
        if (CurrentPlayerJob.job ~= job.name and job.name == "denaros") then 
            DenarosToggleDuty(false)
        elseif (job.name == "unemployed") then
            DenarosToggleDuty(false)
            DenarosSetMarkerDisplay("wash_hands", false)
        end
        CurrentPlayerJob.job = job.name
        CurrentPlayerJob.grade = job.grade
    end
end)

OnScriptStarted(DenarosThread)