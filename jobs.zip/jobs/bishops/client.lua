local CurrentPlayerJob = {job = nil, grade = nil}
local JobData = Config.Jobs.Bishops
local ClockedIn = false
local OvenStatus = {baking = false, type = nil, fire = false, timer = 0}
local AllowInteraction = true
local ActiveFire = nil

function GetBishops(type)
    for i=1, #JobData.CookableItems do 
        if (type == JobData.CookableItems[i].Name) then 
            return JobData.CookableItems[i]
        end
    end
end

function BishopsGetBishopssMenu()
    local menu = {
        {
            id = 1,
            header = "Oven",
            txt = "This is where you can bake anything. Don't forget the ingredients first!"
        },
    }
    for i=1, #JobData.CookableItems do 
        local data = JobData.CookableItems
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "bake_bishops",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function BishopsGetDrinksMenu()
    local menu = {
        {
            id = 1,
            header = "Drink Fountain",
            txt = "This is where you can pour any drinks for a fee."
        },
    }
    for i=1, #JobData.Drinks do 
        local data = JobData.Drinks
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "bishops_drink",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function BishopsGetIngredientsMenu()
    local menu = {
        {
            id = 1,
            header = "Bishops Ingredients",
            txt = "This is where you can grab any ingredients for your bishops. Don't forget the cheese and sauce!"
        },
    }
    for i=1, #JobData.Ingredients do 
        local data = JobData.Ingredients
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label .. " - $" .. data[i].Price,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "bishops_ingredients",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function BishopsGatherAnim()
    LoadAnim('mini@repair') 
    TaskPlayAnim(PlayerPedId(), 'mini@repair', 'fixing_a_player', 8.0, -8, -1, 49, 0, 0, 0, 0)
end

function BishopsStartFire(coords) 
    -- Make some variables for the particle dictionary and particle name.
    local dict = "scr_trevor3"
    local particleName = "scr_trev3_trailer_plume"

    -- Create a new thread.
    Citizen.CreateThread(function()
        -- Request the particle dictionary.
        RequestNamedPtfxAsset(dict)
        -- Wait for the particle dictionary to load.
        while not HasNamedPtfxAssetLoaded(dict) do
            Citizen.Wait(0)
        end
        UseParticleFxAssetNextCall(dict)
        -- Create a new non-looped particle effect, we don't need to store the particle handle because it will
        -- automatically get destroyed once the particle has finished it's animation (it's non-looped).
        ActiveFire = StartParticleFxLoopedAtCoord(particleName, coords.x, coords.y, coords.z, 0.0, 0.0, 0.0, 0.2, false, false, false)
    end)
end

function BishopsStopFire() 
    Citizen.CreateThread(function()
        AllowInteraction = false
        DisplayProgress(5000, "Extinguishing Fire", 'mini@repair', 'fixing_a_player')
        BishopsGatherAnim()
        Citizen.SetTimeout(5000, function()
            ClearPedTasksImmediately(PlayerPedId())
            StopParticleFxLooped(ActiveFire, true)
            ActiveFire = false
            AllowInteraction = true
        end)
    end)
end

function BishopsStartBaking(type)
    if (not OvenStatus.baking and OvenStatus.type == nil) then 
        OvenStatus.baking = true
        OvenStatus.type = type
        OvenStatus.timer = JobData.BishopsCookTime
        Citizen.CreateThread(function() 
            while OvenStatus.type ~= nil do
                OvenStatus.timer = OvenStatus.timer - 1
                if (OvenStatus.timer == 0) then
                    OvenStatus.baking = false
                end 
                if (OvenStatus.timer <= -JobData.OvercookedTime) then
                    OvenStatus.baking = false
                    OvenStatus.type = nil
                    OvenStatus.timer = 0
                    OvenStatus.fire = true
                    BishopsStartFire(JobData.InteractMarkers["bishops_oven"].Coords) 
                    break
                end 
                Citizen.Wait(1000)
            end
        end)
    end
end

function BishopsMakeDough()
    Citizen.CreateThread(function()
        AllowInteraction = false
        DisplayProgress(5000, "Making Bishops Dough", 'mini@repair', 'fixing_a_player')
        BishopsGatherAnim()
        Citizen.Wait(5000)
        ClearPedTasksImmediately(PlayerPedId())
        TriggerServerEvent("esx_societyjobs:bishops:craftDough")
        AllowInteraction = true
    end)
end

function BishopsToggleDuty(bool)
    ClockedIn = bool
    if (ClockedIn) then 
        BishopsSetMarkerDisplay("wash_hands", false)
        BishopsSetMarkerDisplay("clock_out", true)
        BishopsSetMarkerDisplay("boss", true)
        BishopsSetMarkerDisplay("drink_fountain", true)
        BishopsSetMarkerDisplay("bishops_ingredients", true)
        BishopsSetMarkerDisplay("bishops_oven", true)
    else
        BishopsSetMarkerDisplay("wash_hands", true)
        BishopsSetMarkerDisplay("clock_out", false)
        BishopsSetMarkerDisplay("boss", false)
        BishopsSetMarkerDisplay("drink_fountain", false)
        BishopsSetMarkerDisplay("bishops_ingredients", false)
        BishopsSetMarkerDisplay("bishops_oven", false)
    end
end

function BishopsSetMarkerDisplay(key, bool)
    JobData.InteractMarkers[key].Display = bool
end

function BishopsGetMarkerText(key)
    local text = JobData.InteractMarkers[key].DisplayText
    if (key == "bishops_oven") then 
        if OvenStatus.baking then 
            text = text:gsub("|oven_status|", "Baking Timer: " .. OvenStatus.timer .. " second(s)")
        elseif OvenStatus.type ~= nil then
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to take out the ".. GetBishops(OvenStatus.type).Label ..".")
        elseif OvenStatus.fire then
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to extinguish the fire.")
        else
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to use the oven.")
        end
    end
    return text
end

function BishopsInteractMarker(key)
    AllowInteraction = false
    local marker = JobData.InteractMarkers[key]
    if (key == "boss") then 
        OpenSocietyJobBossMenu()
    elseif (key == "clock_out") then 
        BishopsToggleDuty(false)
    elseif (key == "wash_hands") then 
        Citizen.CreateThread(function()
            AllowInteraction = false
            DisplayProgress(5000, "Washing Hands", 'mini@repair', 'fixing_a_player')
            BishopsGatherAnim()
            Citizen.Wait(5000)
            ClearPedTasksImmediately(PlayerPedId())
            BishopsToggleDuty(true)
            AllowInteraction = true
        end)
    elseif (key == "drink_fountain") then 
        TriggerEvent('nh-context-bridge:sendMenu', BishopsGetDrinksMenu())
    elseif (key == "bishops_ingredients") then 
        TriggerEvent('nh-context-bridge:sendMenu', BishopsGetIngredientsMenu())
    elseif (key == "bishops_oven") then 
        if (OvenStatus.fire) then
            OvenStatus.fire = false
            BishopsStopFire() 
        elseif (not OvenStatus.baking and OvenStatus.type ~= nil) then 
            local bishopsType = OvenStatus.type
            OvenStatus.type = nil
            OvenStatus.timer = 0
            OvenStatus.fire = false
            Citizen.CreateThread(function()
                AllowInteraction = false
                DisplayProgress(5000, "Taking Bishops out of Oven", 'mini@repair', 'fixing_a_player')
                BishopsGatherAnim()
                Citizen.Wait(5000)
                ClearPedTasksImmediately(PlayerPedId())
                TriggerServerEvent("esx_societyjobs:bishops:cookedBishops", bishopsType)
                AllowInteraction = true
            end)
        elseif (not OvenStatus.baking and OvenStatus.type == nil) then
            TriggerEvent('nh-context-bridge:sendMenu', BishopsGetBishopssMenu())
        end
    end
    AllowInteraction = true
end

function BishopsThread()
    Citizen.CreateThread(function()
        while true do
            local wait = 1000
            local coords = GetPlayerCoords()
            for k,v in pairs(JobData.InteractMarkers) do 
                if (v.Display or v.Display == nil) then 
                    local dist = #(v.Coords - coords)
                    if (dist < 20.0) then 
                        wait = 0
                        if (Marker(v.Coords, dist, BishopsGetMarkerText(k)) and AllowInteraction) then 
                            BishopsInteractMarker(k)
                        end
                    end
                end
            end
            Citizen.Wait(wait)
        end
    end)
end

RegisterNetEvent("nh-context:returnData")
AddEventHandler("nh-context:returnData", function(_data)
    local key = _data.id
    local data = _data.data
    if (key == "bishops_ingredients") then 
        Citizen.CreateThread(function()
            ESX.TriggerServerCallback("esx_societyjobs:bishops:purchaseIngredient", function(result) 
                if (result) then 
                    Citizen.CreateThread(function()
                        AllowInteraction = false
                        DisplayProgress(5000, "Grabbing Ingredient", 'mini@repair', 'fixing_a_player')
                        BishopsGatherAnim()
                        Citizen.Wait(5000)
                        ClearPedTasksImmediately(PlayerPedId())
                        AllowInteraction = true
                    end)
                else
                    ESX.ShowNotification("You cannot afford this ingredient.")
                end
            end, data.selected)
        end)
    elseif (key == "bake_bishops") then
        AllowInteraction = false
        ESX.TriggerServerCallback("esx_societyjobs:bishops:bakeBishops", function(result) 
            if (result) then 
                Citizen.CreateThread(function()
                    DisplayProgress(5000, "Putting food into Oven", 'mini@repair', 'fixing_a_player')
                    BishopsGatherAnim()
                    Citizen.Wait(5000)
                    ClearPedTasksImmediately(PlayerPedId())
                    BishopsStartBaking(result)
                    AllowInteraction = true
                end)
            else
                ESX.ShowNotification("Missing Ingredients for the Bishops.")
                AllowInteraction = true
            end
        end, data.selected)
    elseif (key == "bishops_drink") then
        AllowInteraction = false
        ESX.TriggerServerCallback("esx_societyjobs:bishops:getDrink", function(result) 
            if (result) then 
                Citizen.CreateThread(function()
                    DisplayProgress(5000, "Pouring Drink", 'mini@repair', 'fixing_a_player')
                    BishopsGatherAnim()
                    Citizen.Wait(5000)
                    ClearPedTasksImmediately(PlayerPedId())
                    AllowInteraction = true
                end)
            else
                ESX.ShowNotification("You cannot afford the drink.")
                AllowInteraction = true
            end
        end, data.selected)
    end
end)

RegisterNetEvent('esx_societyjobs:jobUpdated')
AddEventHandler('esx_societyjobs:jobUpdated', function(job)
    if (not CurrentPlayerJob.job or (CurrentPlayerJob.job ~= job.name or CurrentPlayerJob.grade ~= job.grade)) then 
        if (CurrentPlayerJob.job ~= job.name and job.name == "bishops") then 
            BishopsToggleDuty(false)
        elseif (job.name == "unemployed") then
            BishopsToggleDuty(false)
            BishopsSetMarkerDisplay("wash_hands", false)
        end
        CurrentPlayerJob.job = job.name
        CurrentPlayerJob.grade = job.grade
    end
end)

OnScriptStarted(BishopsThread)