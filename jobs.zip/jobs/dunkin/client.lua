local CurrentPlayerJob = {job = nil, grade = nil}
local JobData = Config.Jobs.Dunkin
local ClockedIn = false
local OvenStatus = {baking = false, type = nil, fire = false, timer = 0}
local AllowInteraction = true
local ActiveFire = nil

function GetDunkin(type)
    for i=1, #JobData.CookableItems do 
        if (type == JobData.CookableItems[i].Name) then 
            return JobData.CookableItems[i]
        end
    end
end

function DunkinGetDunkinsMenu()
    local menu = {
        {
            id = 1,
            header = "Bake Donut",
            txt = "This is where you can bake any donut. Don't forget the flavors first!"
        },
    }
    for i=1, #JobData.CookableItems do 
        local data = JobData.CookableItems
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "bake_dunkin",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function DunkinGetDrinksMenu()
    local menu = {
        {
            id = 1,
            header = "Drink Fountain",
            txt = "This is where you can pour any drinks for a fee."
        },
    }
    for i=1, #JobData.Drinks do 
        local data = JobData.Drinks
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "dunkin_drink",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function DunkinGetIngredientsMenu()
    local menu = {
        {
            id = 1,
            header = "Donut Ingredients",
            txt = "This is where you can grab any ingredients for your donut. Don't forget the dough!"
        },
    }
    for i=1, #JobData.Ingredients do 
        local data = JobData.Ingredients
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label .. " - $" .. data[i].Price,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "dunkin_ingredients",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function DunkinGatherAnim()
    LoadAnim('mini@repair') 
    TaskPlayAnim(PlayerPedId(), 'mini@repair', 'fixing_a_player', 8.0, -8, -1, 49, 0, 0, 0, 0)
end

function DunkinStartFire(coords) 
    -- Make some variables for the particle dictionary and particle name.
    local dict = "scr_trevor3"
    local particleName = "scr_trev3_trailer_plume"

    -- Create a new thread.
    Citizen.CreateThread(function()
        -- Request the particle dictionary.
        RequestNamedPtfxAsset(dict)
        -- Wait for the particle dictionary to load.
        while not HasNamedPtfxAssetLoaded(dict) do
            Citizen.Wait(0)
        end
        UseParticleFxAssetNextCall(dict)
        -- Create a new non-looped particle effect, we don't need to store the particle handle because it will
        -- automatically get destroyed once the particle has finished it's animation (it's non-looped).
        ActiveFire = StartParticleFxLoopedAtCoord(particleName, coords.x, coords.y, coords.z, 0.0, 0.0, 0.0, 0.2, false, false, false)
    end)
end

function DunkinStopFire() 
    Citizen.CreateThread(function()
        AllowInteraction = false
        DisplayProgress(5000, "Extinguishing Fire", 'mini@repair', 'fixing_a_player')
        DunkinGatherAnim()
        Citizen.SetTimeout(5000, function()
            ClearPedTasksImmediately(PlayerPedId())
            StopParticleFxLooped(ActiveFire, true)
            ActiveFire = false
            AllowInteraction = true
        end)
    end)
end

function DunkinStartBaking(type)
    if (not OvenStatus.baking and OvenStatus.type == nil) then 
        OvenStatus.baking = true
        OvenStatus.type = type
        OvenStatus.timer = JobData.DunkinCookTime
        Citizen.CreateThread(function() 
            while OvenStatus.type ~= nil do
                OvenStatus.timer = OvenStatus.timer - 1
                if (OvenStatus.timer == 0) then
                    OvenStatus.baking = false
                end 
                if (OvenStatus.timer <= -JobData.OvercookedTime) then
                    OvenStatus.baking = false
                    OvenStatus.type = nil
                    OvenStatus.timer = 0
                    OvenStatus.fire = true
                    DunkinStartFire(JobData.InteractMarkers["dunkin_oven"].Coords) 
                    break
                end 
                Citizen.Wait(1000)
            end
        end)
    end
end

function DunkinMakeDough()
    Citizen.CreateThread(function()
        AllowInteraction = false
        DisplayProgress(5000, "Making Donut Dough", 'mini@repair', 'fixing_a_player')
        DunkinGatherAnim()
        Citizen.Wait(5000)
        ClearPedTasksImmediately(PlayerPedId())
        TriggerServerEvent("esx_societyjobs:dunkin:craftDough")
        AllowInteraction = true
    end)
end

function DunkinToggleDuty(bool)
    ClockedIn = bool
    if (ClockedIn) then 
        DunkinSetMarkerDisplay("wash_hands", false)
        DunkinSetMarkerDisplay("clock_out", true)
        DunkinSetMarkerDisplay("boss", true)
        DunkinSetMarkerDisplay("drink_fountain", true)
        DunkinSetMarkerDisplay("dunkin_dough", true)
        DunkinSetMarkerDisplay("dunkin_ingredients", true)
        DunkinSetMarkerDisplay("dunkin_oven", true)
    else
        DunkinSetMarkerDisplay("wash_hands", true)
        DunkinSetMarkerDisplay("clock_out", false)
        DunkinSetMarkerDisplay("boss", false)
        DunkinSetMarkerDisplay("drink_fountain", false)
        DunkinSetMarkerDisplay("dunkin_dough", false)
        DunkinSetMarkerDisplay("dunkin_ingredients", false)
        DunkinSetMarkerDisplay("dunkin_oven", false)
    end
end

function DunkinSetMarkerDisplay(key, bool)
    JobData.InteractMarkers[key].Display = bool
end

function DunkinGetMarkerText(key)
    local text = JobData.InteractMarkers[key].DisplayText
    if (key == "dunkin_oven") then 
        if OvenStatus.baking then 
            text = text:gsub("|oven_status|", "Baking Timer: " .. OvenStatus.timer .. " second(s)")
        elseif OvenStatus.type ~= nil then
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to take out the ".. GetDunkin(OvenStatus.type).Label ..".")
        elseif OvenStatus.fire then
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to extinguish the fire.")
        else
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to bake a donut.")
        end
    end
    return text
end

function DunkinInteractMarker(key)
    AllowInteraction = false
    local marker = JobData.InteractMarkers[key]
    if (key == "boss") then 
        OpenSocietyJobBossMenu()
    elseif (key == "clock_out") then 
        DunkinToggleDuty(false)
    elseif (key == "wash_hands") then 
        Citizen.CreateThread(function()
            AllowInteraction = false
            DisplayProgress(5000, "Washing Hands", 'mini@repair', 'fixing_a_player')
            DunkinGatherAnim()
            Citizen.Wait(5000)
            ClearPedTasksImmediately(PlayerPedId())
            DunkinToggleDuty(true)
            AllowInteraction = true
        end)
    elseif (key == "drink_fountain") then 
        TriggerEvent('nh-context-bridge:sendMenu', DunkinGetDrinksMenu())
    elseif (key == "dunkin_dough") then
        DunkinMakeDough()
    elseif (key == "dunkin_ingredients") then 
        TriggerEvent('nh-context-bridge:sendMenu', DunkinGetIngredientsMenu())
    elseif (key == "dunkin_oven") then 
        if (OvenStatus.fire) then
            OvenStatus.fire = false
            DunkinStopFire() 
        elseif (not OvenStatus.baking and OvenStatus.type ~= nil) then 
            local dunkinType = OvenStatus.type
            OvenStatus.type = nil
            OvenStatus.timer = 0
            OvenStatus.fire = false
            Citizen.CreateThread(function()
                AllowInteraction = false
                DisplayProgress(5000, "Taking Donut out of Oven", 'mini@repair', 'fixing_a_player')
                DunkinGatherAnim()
                Citizen.Wait(5000)
                ClearPedTasksImmediately(PlayerPedId())
                TriggerServerEvent("esx_societyjobs:dunkin:cookedDunkin", dunkinType)
                AllowInteraction = true
            end)
        elseif (not OvenStatus.baking and OvenStatus.type == nil) then
            TriggerEvent('nh-context-bridge:sendMenu', DunkinGetDunkinsMenu())
        end
    end
    AllowInteraction = true
end

function DunkinThread()
    Citizen.CreateThread(function()
        while true do
            local wait = 1000
            local coords = GetPlayerCoords()
            for k,v in pairs(JobData.InteractMarkers) do 
                if (v.Display or v.Display == nil) then 
                    local dist = #(v.Coords - coords)
                    if (dist < 20.0) then 
                        wait = 0
                        if (Marker(v.Coords, dist, DunkinGetMarkerText(k)) and AllowInteraction) then 
                            DunkinInteractMarker(k)
                        end
                    end
                end
            end
            Citizen.Wait(wait)
        end
    end)
end

RegisterNetEvent("nh-context:returnData")
AddEventHandler("nh-context:returnData", function(_data)
    local key = _data.id
    local data = _data.data
    if (key == "dunkin_ingredients") then 
        AllowInteraction = false
        Citizen.CreateThread(function()
            ESX.TriggerServerCallback("esx_societyjobs:dunkin:purchaseIngredient", function(result) 
                if (result) then 
                    Citizen.CreateThread(function()
                        DisplayProgress(5000, "Grabbing Ingredient", 'mini@repair', 'fixing_a_player')
                        DunkinGatherAnim()
                        Citizen.Wait(5000)
                        ClearPedTasksImmediately(PlayerPedId())
                        AllowInteraction = true
                    end)
                else
                    ESX.ShowNotification("You cannot afford this ingredient.")
                    AllowInteraction = true
                end
            end, data.selected)
        end)
    elseif (key == "bake_dunkin") then
        AllowInteraction = false
        ESX.TriggerServerCallback("esx_societyjobs:dunkin:bakeDunkin", function(result) 
            if (result) then 
                Citizen.CreateThread(function()
                    DisplayProgress(5000, "Putting Donut into Oven", 'mini@repair', 'fixing_a_player')
                    DunkinGatherAnim()
                    Citizen.Wait(5000)
                    ClearPedTasksImmediately(PlayerPedId())
                    DunkinStartBaking(result)
                    AllowInteraction = true
                end)
            else
                ESX.ShowNotification("Missing Ingredients for the Donut.")
                AllowInteraction = true
            end
        end, data.selected)
    elseif (key == "dunkin_drink") then
        AllowInteraction = false
        ESX.TriggerServerCallback("esx_societyjobs:dunkin:getDrink", function(result) 
            if (result) then 
                Citizen.CreateThread(function()
                    DisplayProgress(5000, "Pouring Drink", 'mini@repair', 'fixing_a_player')
                    DunkinGatherAnim()
                    Citizen.Wait(5000)
                    ClearPedTasksImmediately(PlayerPedId())
                    AllowInteraction = true
                end)
            else
                ESX.ShowNotification("You cannot afford the drink.")
                AllowInteraction = true
            end
        end, data.selected)
    end
end)

RegisterNetEvent('esx_societyjobs:jobUpdated')
AddEventHandler('esx_societyjobs:jobUpdated', function(job)
    if (not CurrentPlayerJob.job or (CurrentPlayerJob.job ~= job.name or CurrentPlayerJob.grade ~= job.grade)) then 
        if (CurrentPlayerJob.job ~= job.name and job.name == "dunkindonuts") then 
            DunkinToggleDuty(false)
            DunkinSetMarkerDisplay("wash_hands", true)
        elseif (job.name ~= "dunkindonuts") then
            DunkinToggleDuty(false)
            DunkinSetMarkerDisplay("wash_hands", false)
        end
        CurrentPlayerJob.job = job.name
        CurrentPlayerJob.grade = job.grade
    end
end)

OnScriptStarted(DunkinThread)