local CurrentPlayerJob = {job = nil, grade = nil}
local JobData = Config.Jobs.Ammunation
local ClockedIn = false
local OvenStatus = {baking = false, type = nil, fire = false, timer = 0}
local AllowInteraction = true
local ActiveFire = nil

function GetAmmunation(type)
    for i=1, #JobData.CookableItems do 
        if (type == JobData.CookableItems[i].Name) then 
            return JobData.CookableItems[i]
        end
    end
end

function AmmunationGetAmmunationsMenu()
    local menu = {
        {
            id = 1,
            header = "Craft Weapons",
            txt = "This is where you can craft any weapons. Don't forget the parts first!"
        },
    }
    for i=1, #JobData.CookableItems do 
        local data = JobData.CookableItems
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "bake_ammunation",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function AmmunationGetIngredientsMenu()
    local menu = {
        {
            id = 1,
            header = "Weapon Crafting",
            txt = "This is where you can grab any parts for your weapon."
        },
    }
    for i=1, #JobData.Ingredients do 
        local data = JobData.Ingredients
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label .. " - $" .. data[i].Price,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "ammunation_ingredients",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function AmmunationGatherAnim()
    LoadAnim('mini@repair') 
    TaskPlayAnim(PlayerPedId(), 'mini@repair', 'fixing_a_player', 8.0, -8, -1, 49, 0, 0, 0, 0)
end

function AmmunationStartFire(coords) 
    -- Make some variables for the particle dictionary and particle name.
    local dict = "scr_trevor3"
    local particleName = "scr_trev3_trailer_plume"

    -- Create a new thread.
    Citizen.CreateThread(function()
        -- Request the particle dictionary.
        RequestNamedPtfxAsset(dict)
        -- Wait for the particle dictionary to load.
        while not HasNamedPtfxAssetLoaded(dict) do
            Citizen.Wait(0)
        end
        UseParticleFxAssetNextCall(dict)
        -- Create a new non-looped particle effect, we don't need to store the particle handle because it will
        -- automatically get destroyed once the particle has finished it's animation (it's non-looped).
        ActiveFire = StartParticleFxLoopedAtCoord(particleName, coords.x, coords.y, coords.z, 0.0, 0.0, 0.0, 0.2, false, false, false)
    end)
end

function AmmunationStopFire() 
    Citizen.CreateThread(function()
        AllowInteraction = false
        DisplayProgress(5000, "Extinguishing Fire", 'mini@repair', 'fixing_a_player')
        AmmunationGatherAnim()
        Citizen.SetTimeout(5000, function()
            ClearPedTasksImmediately(PlayerPedId())
            StopParticleFxLooped(ActiveFire, true)
            ActiveFire = false
            AllowInteraction = true
        end)
    end)
end

function AmmunationStartBaking(type)
    if (not OvenStatus.baking and OvenStatus.type == nil) then 
        OvenStatus.baking = true
        OvenStatus.type = type
        OvenStatus.timer = JobData.AmmunationCookTime
        Citizen.CreateThread(function() 
            while OvenStatus.type ~= nil do
                OvenStatus.timer = OvenStatus.timer - 1
                if (OvenStatus.timer == 0) then
                    OvenStatus.baking = false
                end 
                if (OvenStatus.timer <= -JobData.OvercookedTime) then
                    OvenStatus.baking = false
                    OvenStatus.type = nil
                    OvenStatus.timer = 0
                    OvenStatus.fire = true
                    AmmunationStartFire(JobData.InteractMarkers["ammunation_oven"].Coords) 
                    break
                end 
                Citizen.Wait(1000)
            end
        end)
    end
end

function AmmunationToggleDuty(bool)
    ClockedIn = bool
    if (ClockedIn) then 
        AmmunationSetMarkerDisplay("toggle_duty", true)
        AmmunationSetMarkerDisplay("boss", true)
        AmmunationSetMarkerDisplay("ammunation_ingredients", true)
        AmmunationSetMarkerDisplay("ammunation_oven", true)
    else
        AmmunationSetMarkerDisplay("toggle_duty", true)
        AmmunationSetMarkerDisplay("boss", false)
        AmmunationSetMarkerDisplay("ammunation_ingredients", false)
        AmmunationSetMarkerDisplay("ammunation_oven", false)
    end
end

function AmmunationSetMarkerDisplay(key, bool)
    JobData.InteractMarkers[key].Display = bool
end

function AmmunationGetMarkerText(key)
    local text = JobData.InteractMarkers[key].DisplayText
    if (key == "ammunation_oven") then 
        if OvenStatus.baking then 
            text = text:gsub("|oven_status|", "Crafting Timer: " .. OvenStatus.timer .. " second(s)")
        elseif OvenStatus.type ~= nil then
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to take out the ".. GetAmmunation(OvenStatus.type).Label ..".")
        elseif OvenStatus.fire then
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to extinguish the fire.")
        else
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to craft a weapon.")
        end
    elseif (key == "toggle_duty") then 
        text = text:gsub("|clocked_status|", (ClockedIn and "out" or "in"))
    end
    return text
end

function AmmunationInteractMarker(key)
    AllowInteraction = false
    local marker = JobData.InteractMarkers[key]
    if (key == "boss") then 
        OpenSocietyJobBossMenu()
    elseif (key == "toggle_duty") then 
        AmmunationToggleDuty(not ClockedIn)
    elseif (key == "ammunation_ingredients") then 
        TriggerEvent('nh-context-bridge:sendMenu', AmmunationGetIngredientsMenu())
    elseif (key == "ammunation_oven") then 
        if (OvenStatus.fire) then
            OvenStatus.fire = false
            AmmunationStopFire() 
        elseif (not OvenStatus.baking and OvenStatus.type ~= nil) then 
            local ammunationType = OvenStatus.type
            OvenStatus.type = nil
            OvenStatus.timer = 0
            OvenStatus.fire = false
            Citizen.CreateThread(function()
                AllowInteraction = false
                DisplayProgress(5000, "Grabbing the Crafted Item", 'mini@repair', 'fixing_a_player')
                AmmunationGatherAnim()
                Citizen.Wait(5000)
                ClearPedTasksImmediately(PlayerPedId())
                TriggerServerEvent("esx_societyjobs:ammunation:cookedAmmunation", ammunationType)
                AllowInteraction = true
            end)
        elseif (not OvenStatus.baking and OvenStatus.type == nil) then
            TriggerEvent('nh-context-bridge:sendMenu', AmmunationGetAmmunationsMenu())
        end
    end
    AllowInteraction = true
end

function AmmunationThread()
    Citizen.CreateThread(function()
        while true do
            local wait = 1000
            local coords = GetPlayerCoords()
            for k,v in pairs(JobData.InteractMarkers) do 
                if (v.Display or v.Display == nil) then 
                    local dist = #(v.Coords - coords)
                    if (dist < 20.0) then 
                        wait = 0
                        if (Marker(v.Coords, dist, AmmunationGetMarkerText(k)) and AllowInteraction) then 
                            AmmunationInteractMarker(k)
                        end
                    end
                end
            end
            Citizen.Wait(wait)
        end
    end)
end

RegisterNetEvent("nh-context:returnData")
AddEventHandler("nh-context:returnData", function(_data)
    local key = _data.id
    local data = _data.data
    if (key == "ammunation_ingredients") then 
        Citizen.CreateThread(function()
            ESX.TriggerServerCallback("esx_societyjobs:ammunation:purchaseIngredient", function(result) 
                if (result) then 
                    Citizen.CreateThread(function()
                        AllowInteraction = false
                        DisplayProgress(5000, "Grabbing Ingredient", 'mini@repair', 'fixing_a_player')
                        AmmunationGatherAnim()
                        Citizen.Wait(5000)
                        ClearPedTasksImmediately(PlayerPedId())
                        AllowInteraction = true
                    end)
                else
                    ESX.ShowNotification("You cannot afford this ingredient.")
                end
            end, data.selected)
        end)
    elseif (key == "bake_ammunation") then
        AllowInteraction = false
        ESX.TriggerServerCallback("esx_societyjobs:ammunation:bakeAmmunation", function(result) 
            if (result) then 
                Citizen.CreateThread(function()
                    DisplayProgress(5000, "Putting Items on the Crafting Bench", 'mini@repair', 'fixing_a_player')
                    AmmunationGatherAnim()
                    Citizen.Wait(5000)
                    ClearPedTasksImmediately(PlayerPedId())
                    AmmunationStartBaking(result)
                    AllowInteraction = true
                end)
            else
                ESX.ShowNotification("Missing Ingredients for the Ammunation.")
                AllowInteraction = true
            end
        end, data.selected)
    end
end)

RegisterNetEvent('esx_societyjobs:jobUpdated')
AddEventHandler('esx_societyjobs:jobUpdated', function(job)
    if (not CurrentPlayerJob.job or (CurrentPlayerJob.job ~= job.name or CurrentPlayerJob.grade ~= job.grade)) then 
        if (CurrentPlayerJob.job ~= job.name and job.name == "ammunation") then 
            AmmunationToggleDuty(false)
        elseif (job.name == "unemployed") then
            AmmunationToggleDuty(false)
            AmmunationSetMarkerDisplay("toggle_duty", false)
        end
        CurrentPlayerJob.job = job.name
        CurrentPlayerJob.grade = job.grade
    end
end)

OnScriptStarted(AmmunationThread)