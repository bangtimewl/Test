local JobData = Config.Jobs.Barber
local InstructionCount = 0 
local CurrentChair = nil
local PlayerData = {}

Citizen.CreateThread(function()
    while ESX == nil do Citizen.Wait(0) end
    while ESX.GetPlayerData() == nil do Citizen.Wait(0) end
    while ESX.GetPlayerData().job == nil do Citizen.Wait(0) end

    PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
    PlayerData.job = job
end)

function ButtonMessage(text)
    BeginTextCommandScaleformString("STRING")
    AddTextComponentScaleform(text)
    EndTextCommandScaleformString()
end

function Button(ControlButton)
    N_0xe83a3e3557a56640(ControlButton)
end

function setupScaleform(entries)
    local scaleform = RequestScaleformMovie("instructional_buttons")
    while not HasScaleformMovieLoaded(scaleform) do
        Citizen.Wait(0)
    end

    -- draw it once to set up layout
    DrawScaleformMovieFullscreen(scaleform, 255, 255, 255, 0, 0)

    PushScaleformMovieFunction(scaleform, "CLEAR_ALL")
    PopScaleformMovieFunctionVoid()
    
    PushScaleformMovieFunction(scaleform, "SET_CLEAR_SPACE")
    PushScaleformMovieFunctionParameterInt(200)
    PopScaleformMovieFunctionVoid()
    
    -- {message = "hi"}
    for i=1, #entries do 
        PushScaleformMovieFunction(scaleform, "SET_DATA_SLOT")
        PushScaleformMovieFunctionParameterInt(i - 1)
        if (entries[i].control) then 
            Button(GetControlInstructionalButton(entries[i].control[1], entries[i].control[2], true))
        end
        ButtonMessage(entries[i].message)
        PopScaleformMovieFunctionVoid()
    end

    PushScaleformMovieFunction(scaleform, "DRAW_INSTRUCTIONAL_BUTTONS")
    PopScaleformMovieFunctionVoid()

    PushScaleformMovieFunction(scaleform, "SET_BACKGROUND_COLOUR")
    PushScaleformMovieFunctionParameterInt(0)
    PushScaleformMovieFunctionParameterInt(0)
    PushScaleformMovieFunctionParameterInt(0)
    PushScaleformMovieFunctionParameterInt(80)
    PopScaleformMovieFunctionVoid()

    return scaleform
end

function UpdateInstructionBar(data)
    InstructionCount = InstructionCount + 1
    local count = InstructionCount
    if (data ~= nil) then 
        Citizen.CreateThread(function()
            local form = setupScaleform(data)
            while count == InstructionCount do
                Citizen.Wait(0)
                DrawScaleformMovieFullscreen(form, 255, 255, 255, 255, 0)
            end
        end)
    end
end

function GetOffsetCoords(vec1, vec2)
    return vec1 + vec2
end

function GetComponentData(name, cb)
    TriggerEvent('skinchanger:getData', function(comp, max)
        components, maxVals = comp, max
        for i=1, #components do 
            if (components[i].name == name) then 
                local data = components[i]
                data.max = maxVals[components[i].name]
                cb(data)
                return
            end
        end
    end)
end

function HaircutAnimation2(storeID, chairID)
    
    local chairData = JobData.Stores[storeID].Chairs[chairID]
    SetPlayerCanUseCover(PlayerId(), true)
    local player = PlayerPedId()
    local propHash = 'prop_cs_scissors'
    local x, y, z = table.unpack(GetOffsetFromEntityInWorldCoords(PlayerPedId(),0.0,3.0,0.5))
    RequestModel(propHash)
    while not HasModelLoaded(propHash) do Citizen.Wait(0) end
    local scissors = CreateObjectNoOffset(propHash, x, y, z, true, false)
    SetModelAsNoLongerNeeded(propHash)
    AttachEntityToEntity(scissors, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 57005), 0.1, 0.0, -0.02, 0, 0.0, 0.0, true, true, false, true, 1, true) -- object is attached to right hand 
    while (not HasAnimDictLoaded("misshair_shop@barbers")) do
        RequestAnimDict("misshair_shop@barbers")
        Citizen.Wait(5)
    end
    
    TaskPlayAnim(player, "misshair_shop@barbers", "keeper_idle_b", 8.0, 8.0, 15000, 16, 0, false, false, false)
    
    Wait(3000)
    Wait(8000)
    
    DeleteEntity(scissors)
    SetModelAsNoLongerNeeded(propHash)
    
    TriggerServerEvent("barber:saveChanges", chairData.sitting)
    
    InteractChair(storeID, chairID, "leaveBarber")
end

function GetOptions(storeID) 
    return JobData.Types[JobData.Stores[storeID].Type].Options
end

function InteractChair(storeID, chairID, _type)
    local chairData = JobData.Stores[storeID].Chairs[chairID]
    if (_type == "startHaircut") then 
        UpdateInstructionBar()
        HaircutAnimation2(storeID, chairID)
    elseif (_type == "barberChair") then 
        CurrentChair = {store = storeID, chair = chairID} 
        Citizen.CreateThread(function()
            local optionIndex = 1
            local options = GetOptions(storeID)
            ESX.TriggerServerCallback('barber:getPlayerSkin', function(skin, jobSkin)
                for i=1, #options do 
                    options[i].value = skin[options[i].datatype]
                end
            end, chairData.sitting)
            GetComponentData(options[optionIndex].datatype, function(data) 
                UpdateInstructionBar({
                    {message = "Value (Left / Right): " .. options[optionIndex].value .. " / " .. data.max},
                    {message = "Option (Up / Down): " .. options[optionIndex].text},
                    {message = "Start Haircut", control = {1, 176}},
                    {message = "Cancel Haircut", control = {1, 177}},
                })
            end)
            Citizen.Wait(1000)
            Citizen.CreateThread(function()
                while CurrentChair ~= nil do
                    if (IsControlPressed(1, 176)) then 
                        InteractChair(CurrentChair.store, CurrentChair.chair, "startHaircut")
                    elseif (IsControlPressed(1, 177)) then 
                        InteractChair(CurrentChair.store, CurrentChair.chair, "leaveBarber")
                    end
                    Citizen.Wait(0)
                end
            end)
            Citizen.CreateThread(function()
                while CurrentChair ~= nil and JobData.Stores[storeID].Chairs[chairID].sitting do 
                    if (IsControlPressed(1, 173)) then
                        if (optionIndex == 1) then 
                            optionIndex = #options
                        else
                            optionIndex = optionIndex - 1
                        end
                        local currentOption = options[optionIndex]
                        GetComponentData(currentOption.datatype, function(data) 
                            UpdateInstructionBar({
                                {message = "Value (Left / Right): " .. options[optionIndex].value .. " / " .. data.max},
                                {message = "Option (Up / Down): " .. currentOption.text},
                                {message = "Start Haircut", control = {1, 176}},
                                {message = "Cancel Haircut", control = {1, 177}},
                            })
                        end)
                    elseif (IsControlPressed(1, 172)) then 
                        if (optionIndex == #options) then 
                            optionIndex = 1
                        else
                            optionIndex = optionIndex + 1
                        end
                        local currentOption = options[optionIndex]
                        GetComponentData(currentOption.datatype, function(data) 
                            UpdateInstructionBar({
                                {message = "Value (Left / Right): " .. options[optionIndex].value .. " / " .. data.max},
                                {message = "Option (Up / Down): " .. currentOption.text},
                                {message = "Start Haircut", control = {1, 176}},
                                {message = "Cancel Haircut", control = {1, 177}},
                            })
                        end)
                    elseif (IsControlPressed(1, 175)) then 
                        local currentOption = options[optionIndex]
                        GetComponentData(currentOption.datatype, function(data) 
                            if currentOption.value < data.max then 
                                options[optionIndex].value = options[optionIndex].value + 1
                                TriggerServerEvent('barber:syncChange', chairData.sitting, options[optionIndex].datatype, options[optionIndex].value)
                                UpdateInstructionBar({
                                    {message = "Value (Left / Right): " .. options[optionIndex].value .. " / " .. data.max},
                                    {message = "Option (Up / Down): " .. currentOption.text},
                                    {message = "Start Haircut", control = {1, 176}},
                                    {message = "Cancel Haircut", control = {1, 177}},
                                })
                            end
                        end)
                    elseif (IsControlPressed(1, 174)) then 
                        local currentOption = options[optionIndex]
                        GetComponentData(currentOption.datatype, function(data) 
                            if currentOption.value > data.min then 
                                options[optionIndex].value = options[optionIndex].value - 1
                                TriggerServerEvent('barber:syncChange', chairData.sitting, options[optionIndex].datatype, options[optionIndex].value)
                                UpdateInstructionBar({
                                    {message = "Value (Left / Right): " .. options[optionIndex].value .. " / " .. data.max},
                                    {message = "Option (Up / Down): " .. currentOption.text},
                                    {message = "Start Haircut", control = {1, 176}},
                                    {message = "Cancel Haircut", control = {1, 177}},
                                })
                            end
                        end)
                    end
                    Citizen.Wait(100)
                end
            end)
        end)
    elseif (_type == "leaveBarber") then 
        CurrentChair = nil
        UpdateInstructionBar()
        
        UpdateInstructionBar()
    elseif (_type == "leaveChair") then
        ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
            TriggerEvent("esx_skin:save", skin)
        end)

        local playerCoords = GetEntityCoords(PlayerPedId())
        SetEntityCollision(PlayerPedId(),true)
        FreezeEntityPosition(PlayerPedId(),false)
        SetEntityCoords(PlayerPedId(),playerCoords.x,playerCoords.y-1,playerCoords.z)
        ClearPedTasks(PlayerPedId())

        TriggerServerEvent("barber:chairSetData", storeID, chairID, "sitting", false)

        CurrentChair = nil
        
        UpdateInstructionBar()
        return
    elseif (_type == "enterChair") then 
        if (not chairData.sitting) then 
            TriggerServerEvent("barber:chairSetData", storeID, chairID, "sitting", GetPlayerServerId(PlayerId()))
        else
            ESX.ShowNotification("BRUH! WE ALREADY SITTING")
            return
        end
        SetEntityHeading(PlayerPedId(), chairData.Heading)
        SetEntityCoords(PlayerPedId(),chairData.Location.x, chairData.Location.y, chairData.Location.z - 0.4)
        SetEntityCollision(PlayerPedId(),false)

        FreezeEntityPosition(PlayerPedId(),true)
        TaskStartScenarioInPlace(PlayerPedId(), 'PROP_HUMAN_SEAT_CHAIR_MP_PLAYER')

        TriggerEvent('skinchanger:change', "helmet_1", -1)
        
        CurrentChair = {store = storeID, chair = chairID}

        Citizen.Wait(1000)
        UpdateInstructionBar({
            {message = "Cancel Haircut", control = {1, 177}},
        })
        while CurrentChair ~= nil do 
            if (IsControlPressed(1, 177)) then
                InteractChair(CurrentChair.store, CurrentChair.chair, "leaveChair")
            end
            Citizen.Wait(0)
        end
    end
end

OnScriptStarted(function()
    Citizen.CreateThread(function()
        TriggerServerEvent("barber:requestSync")
        while true do 
            local wait = 1000
            for k,v in pairs(JobData.Stores) do 
                for i=1, #v.Chairs do
                    local coords = GetOffsetCoords(v.Chairs[i].Location, v.Chairs[i].Offset)
                    local dist = #(coords - GetEntityCoords(PlayerPedId()))
                    if (CurrentChair == nil and dist < 20.0) then 
                        wait = 0
                        if (not v.Chairs[i].sitting) then
                            if (Marker(coords + vector3(0.0, 0.0, 0.5), dist, "Press ~INPUT_CONTEXT~ to get a fresh cut.")) then 
                                InteractChair(k, i, "enterChair")
                            end
                        else
                            if PlayerData.job then
                                if PlayerData.job.name == "nailsalon" then
                                    if (Marker(coords + vector3(0.0, 0.0, 0.5), dist, "Press ~INPUT_CONTEXT~ to cut their hair.")) then 
                                        InteractChair(k, i, "barberChair")
                                    end
                                end
                            end
                        end
                    end
                end
                if (PlayerData.job.name == "nailsalon" and PlayerData.job.grade_name == "boss") then 
                    local coords = v.Management
                    local dist = #(coords - GetEntityCoords(PlayerPedId()))
                    if (CurrentChair == nil and dist < 20.0) then 
                        wait = 0
                        if (Marker(coords, dist, "Press ~INPUT_CONTEXT~ to manage the nailsalon.")) then 
                            OpenSocietyJobBossMenu()
                        end
                    end
                end
            end
            Citizen.Wait(wait)
        end
    end)
end)

-- Citizen.CreateThread(function()
    -- for k,v in pairs(JobData.Stores) do 
        -- local coords = v.Management
		-- local blip = AddBlipForCoord(coords.x, coords.y, coords.z)

		-- SetBlipSprite (blip, 71)
		-- SetBlipDisplay(blip, 4)
		-- SetBlipScale  (blip, 1.0)
		-- SetBlipColour (blip, 51)
		-- SetBlipAsShortRange(blip, true)

		-- BeginTextCommandSetBlipName("STRING")
		-- AddTextComponentString("Barbershop")
		-- EndTextCommandSetBlipName(blip)
	-- end
-- end)

RegisterNetEvent("barber:syncChange")
AddEventHandler("barber:syncChange", function(_type, value)
    TriggerEvent('skinchanger:change', _type, value)
end)

RegisterNetEvent("barber:syncRequest")
AddEventHandler("barber:syncRequest", function(value)
    JobData.Stores = value
end)

RegisterNetEvent("barber:syncChairStatus")
AddEventHandler("barber:syncChairStatus", function(store, chair, _type, value)
    JobData.Stores[store].Chairs[chair][_type] = value
end)

RegisterNetEvent("barber:saveChanges")
AddEventHandler("barber:saveChanges", function()
    
    TriggerEvent('skinchanger:getSkin', function(skin)
        
        TriggerServerEvent('esx_skin:save', skin)
        SetTimeout(500, function()
            
            InteractChair(CurrentChair.store, CurrentChair.chair, "leaveChair")
        end)
    end)
end)


--[[   DEBUG ADD CHAIR CODE
function RotationToDirection(rotation)
	local adjustedRotation = 
	{ 
		x = (math.pi / 180) * rotation.x, 
		y = (math.pi / 180) * rotation.y, 
		z = (math.pi / 180) * rotation.z 
	}
	local direction = 
	{
		x = -math.sin(adjustedRotation.z) * math.abs(math.cos(adjustedRotation.x)), 
		y = math.cos(adjustedRotation.z) * math.abs(math.cos(adjustedRotation.x)), 
		z = math.sin(adjustedRotation.x)
	}
	return direction
end

function RayCastGamePlayCamera(distance)
	local cameraRotation = GetGameplayCamRot()
	local cameraCoord = GetGameplayCamCoord()
	local direction = RotationToDirection(cameraRotation)
	local destination = 
	{ 
		x = cameraCoord.x + direction.x * distance, 
		y = cameraCoord.y + direction.y * distance, 
		z = cameraCoord.z + direction.z * distance 
	}
	local a, b, c, d, e = GetShapeTestResult(StartShapeTestRay(cameraCoord.x, cameraCoord.y, cameraCoord.z, destination.x, destination.y, destination.z, -1, -1, 1))
	return b, c, e, direction
end

Citizen.CreateThread(function()
    while true do 
        Citizen.Wait(0)
        if (IsControlJustPressed(1, 51)) then
            local playerCoords = GetEntityCoords(PlayerPedId())
            local hit, coords, entity = RayCastGamePlayCamera(1000.0)
            if (hit) then
                pcall(function () TriggerServerEvent("barber:saveCoords", GetEntityCoords(entity), GetEntityModel(entity)) end)
            end
        end
    end
end)
--]]