JobsNUI = {
    ---@type table<string, fun(data: any, cb: fun(): void): void>
    Actions = {}
}

function JobsNUI:On(event, handler)
    self.Actions[event] = handler
end

function JobsNUI:Emit(eventAction, data)
    SendNUIMessage({
        type = eventAction,
        data = data
    })
end

RegisterNUICallback("handle", function(data, cb)
    if JobsNUI.Actions[data.type] then
        JobsNUI.Actions[data.type](data.data, cb)
    else
        cb('')
    end
end)

JobsNUI:On("close", (function(data, cb)
    SetNuiFocus(false, false)
    cb('')
end))

