

local function GetPlayer(source)
    return ESX.GetPlayerFromId(source)
end

local function HasItem(source, item)
    return exports.ox_inventory:GetItem(source, item)?.count or 0
end

lib.callback.register('mechanic:itemCheck', function(source, item)
    return HasItem(source, item)
end)

local function RemoveItem(source, item, amount)
    local itemData = exports.ox_inventory:GetItem(source, item)
    if not itemData or itemData.count < amount then return false end
    return exports.ox_inventory:RemoveItem(source, item, amount)
end

local function GiveItem(source, item, amount)
    return exports.ox_inventory:AddItem(source, item, amount)
end

local function getSocietyMoney(society)
    local money = nil
    TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
        money = account.money
    end)
    while money == nil do Citizen.Wait(0) end
    return money
end

local function addSocietyMoney(money, society)
    TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
        account.addMoney(money)
    end)
end

local function removeSocietyMoney(money, society)
    TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
        account.removeMoney(money)
    end)
end

RegisterServerEvent('crafting:server:main:mech', function(item)
    local player = GetPlayer(source)
    local itemName, hasIngredients, missingIngredients = item.item, true, ""

    -- Check required ingredients
    for _, ingredient in ipairs(Config.craftingMenu[itemName] or {}) do
        local playerItemCount = HasItem(source, ingredient.item)
        if playerItemCount < ingredient.amount then
            hasIngredients = false
            missingIngredients = missingIngredients .. (ingredient.amount - playerItemCount) .. "x " .. ingredient.item .. ", "
        end
    end

    if hasIngredients then
        for _, ingredient in ipairs(Config.craftingMenu[itemName] or {}) do
            RemoveItem(source, ingredient.item, ingredient.amount)
        end
        GiveItem(source, itemName, 1)
        TriggerClientEvent('esx:showNotification', source, 'You have crafted a ' .. itemName)
    else
        TriggerClientEvent('esx:showNotification', source, 'Missing: ' .. missingIngredients:sub(1, -3))
    end
end)
