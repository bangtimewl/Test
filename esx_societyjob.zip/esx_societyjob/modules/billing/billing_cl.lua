local AllowInteraction = true

function FormatText(text, data)
    local fText = text
    for k, v in pairs(data) do 
        fText = fText:gsub("|" .. k .. "|", v)
    end
    return fText
end

function ShowRegisterMenu(k)
    ESX.TriggerServerCallback("esx_societyjobs:billing:getClosestPlayers", function(players)
        local register = BillingRegisters[k]
        local menu = {
            {
                id = 1,
                header = "Register",
                txt = "Select a person to bill."
            },
        }
        for i = 1, #players do 
            menu[#menu + 1] = {
                id = i + 1,
                header = "CashApp: #" .. players[i].source,
                txt = "Bill this person.",
                params = {
                    event = "nh-context-bridge:returnData",
                    args = {
                        id = k,
                        data = {
                            selected = players[i].source,
                            type = "register",
                        }
                    }
                }
            } 
        end    
        TriggerEvent('nh-context-bridge:sendMenu', menu)
    end, 3.0)
end

function ShowReceiptMenu(k, _data)
    local register = BillingRegisters[k]
    local menu = {
        {
            id = 1,
            header = FormatText(register.receiptFormat.label, _data),
            txt = FormatText(register.receiptFormat.txt, _data)
        },
    }
    for i = 1, #register.receiptFormat.options do 
        local data = register.receiptFormat.options[i]
        menu[#menu + 1] = {
            id = i + 1,
            header = FormatText(data.label, _data),
            txt = FormatText(data.txt, _data),
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = k,
                    data = {
                        selected = data.selected,
                        type = "receipt",
                        data = _data
                    }
                }
            }
        }
    end
    TriggerEvent('nh-context-bridge:sendMenu', menu)
end

function ShowBills(bills)
    local menu = {
        {
            id = 1,
            header = (bills[1] == nil and "Nobody" or bills[1].name) .. "'s Transactions",
            txt = "These are the person's 25 most recent transactions."
        },
    }
    local total = 0
    for i = 1, #bills do 
        local data = bills[i]
        menu[#menu + 1] = {
            id = i + 1,
            header = "Transaction: #" .. data.id,
            txt = "<p style='margin-top: 10px'>Amount: $" .. data.charge .. "</p><p>Job: " .. data.job .. "</p><p style='margin-bottom: 0px'>Date: " .. data.date .. "</p>",
        }
        total = total + tonumber(data.charge)
    end
    menu[1].txt = menu[1].txt .. "<p style='margin-top: 10px; margin-bottom: 0px;'>Total Amount: $" .. total .. "</p>"
    TriggerEvent('nh-context-bridge:sendMenu', menu)
end

function InteractRegister(k) 
    if (BillingRegisters[k].job == nil or PlayerData.job.name == BillingRegisters[k].job) then 
        ShowRegisterMenu(k)
    else
        ESX.ShowNotification("You cannot use this register.")
    end
end

RegisterNetEvent("nh-context:returnData")
AddEventHandler("nh-context:returnData", function(_data)
    local key = _data.id
    local data = _data.data
    if (BillingRegisters[key] ~= nil) then 
        if (data.type == "register") then 
            ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'Enter amount to bill for.', {
                title = "Enter amount to bill for.",
            }, function (data2, menu)
                local amount = tonumber(data2.value)
                
                if amount == nil then
                    ESX.ShowNotification('Invalid amount.')
                else
                    -- Trigger the unified event with action "sendBill"
                    TriggerServerEvent("esx_societyjob", "sendBill", key, data.selected, amount)
                    menu.close()
                end
            end, function (data2, menu)
                menu.close()
            end)
        elseif (data.type == "receipt") then 
            print(json.encode(data.data))
            TriggerServerEvent("esx_societyjob", "billResponse", key, data.selected, data.data)
        end
    end
end)

RegisterNetEvent("esx_societyjob:receiveBill")
AddEventHandler("esx_societyjob:receiveBill", function(k, data)
    ShowReceiptMenu(k, data)
end)

RegisterNetEvent("esx_societyjob:viewSales")
AddEventHandler("esx_societyjob:viewSales", function(data)
    ShowBills(data)
end)

RegisterNetEvent("esx_societyjob:showRegister")
AddEventHandler("esx_societyjob:showRegister", function(k)
    ShowRegisterMenu(k)
end)

Citizen.CreateThread(function()
    while true do 
        local bRegisters = BillingRegisters
        local waitTimer = 1000
        local coords = GetEntityCoords(PlayerPedId())
        for k, v in pairs(bRegisters) do 
            local dist = #(v.coords - coords)
            if dist < 20.0 then 
                waitTimer = 0
                if (AllowInteraction and Marker(v.coords, dist, "Press ~INPUT_CONTEXT~ to use the register.")) then 
                    InteractRegister(k)
                end
            end
        end
        Citizen.Wait(msec)
    end
end)
