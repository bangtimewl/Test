local nextBridgeMenuId = 1

function ParseNHOptions(menu, skipFirst)
    local options = {}
    local startIndex = (skipFirst and 2 or 1)
    for i=startIndex, #menu do
        local option = menu[i]
        options[#options + 1] = {
            title = option.header,
            description = option.txt or nil,
            event = option.params?.event,
            args = option.params or nil,
        }
    end
    return options
end

RegisterNetEvent("nh-context-bridge:sendMenu", function(menu) 
    local menuId = 'bridge_menu_' .. nextBridgeMenuId
    nextBridgeMenuId = nextBridgeMenuId + 1
    lib.registerContext({
        id = menuId,
        title = (menu[1].params and 'Options' or menu[1].header),
        options = ParseNHOptions(menu, (menu[1].params and false or true)),
    })
    lib.showContext(menuId)
end)

RegisterNetEvent("nh-context-bridge:returnData", function(args)
    TriggerEvent("nh-context:returnData", args.args)
end)