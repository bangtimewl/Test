local AllowInteraction = true

function ShowCraftingMenu(k)
    local craft = CraftingTables[k]
    local menu = {
        {
            id = 1,
            header = craft.menu.label,
            txt = craft.menu.text
        },
    }
    for i=1, #craft.items do 
        local data = craft.items[i]
        menu[#menu + 1] = {
            id = i + 1,
            header = data.Label .. " - $" .. data.Price,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = k,
                    data = {
                        selected = data.Name,
                    }
                }
            }
        }
    end
    TriggerEvent('nh-context-bridge:sendMenu', menu)
end

function PickupCraftedItem(k, skipAnim)
    local craft = CraftingTables[k]
    local craftItem = craft.type
    CraftingTables[k].type = nil
    CraftingTables[k].timer = 0
    CraftingTables[k].fire = false
    Citizen.CreateThread(function()
        if skipAnim then
            TriggerServerEvent("esx_societyjob", "craft", k, craftItem)
            return
        end

        AllowInteraction = false
        DisplayProgress(5000, "Taking Item", 'mini@repair', 'fixing_a_player')
        LoadAnim('mini@repair') 
        TaskPlayAnim(PlayerPedId(), 'mini@repair', 'fixing_a_player', 8.0, -8, -1, 49, 0, 0, 0, 0)
        Citizen.Wait(5000)
        ClearPedTasksImmediately(PlayerPedId())
        TriggerServerEvent("esx_societyjob", "craft", k, craftItem)
        
        AllowInteraction = true
    end)
end

function StartCrafting(k, type)
    local craft = CraftingTables[k]
    if not AllowInteraction then return end
    if (not craft.crafting and craft.type == nil) then
        AllowInteraction = false
        local itemData, itemIndex = GetCraft(k, type)
        DisplayProgress(5000, "Crafting Item", 'mini@repair', 'fixing_a_player')
        if craft.items[itemIndex].Emote then
            if craft.heading then
                SetEntityHeading(PlayerPedId(), craft.heading)
            end
            OnEmotePlay(Config.Emotes[craft.items[itemIndex].Emote])
        else
            LoadAnim('mini@repair')
            TaskPlayAnim(PlayerPedId(), 'mini@repair', 'fixing_a_player', 8.0, -8, -1, 49, 0, 0, 0, 0)
        end
        local props = {}
        if craft.items[itemIndex].Props then
            for i=1, #craft.items[itemIndex].Props do 
                local prop = craft.items[itemIndex].Props[i]
                local model = prop.model
                RequestModel(model)
                while not HasModelLoaded(model) do
                    Citizen.Wait(0)
                end
                local obj = CreateObject(model, prop.coords.x, prop.coords.y, prop.coords.z, false, false, false)
                SetEntityRotation(obj, prop.rotation.x, prop.rotation.y, prop.rotation.z, 2)
                table.insert(props, obj)
            end
        end
        Citizen.Wait(5000)
        ClearPedTasksImmediately(PlayerPedId()) 
        DestroyAllProps()
        SetTimeout(100, function() AllowInteraction = true end)
        CraftingTables[k].crafting = true
        CraftingTables[k].type = type
        CraftingTables[k].timer = itemData.CraftTimer
        for i=1, #props do 
            DeleteEntity(props[i])
        end
        props = {}

        if craft.craftOnce then
            CraftingTables[k].crafting = false
            PickupCraftedItem(k, true)
            return
        end
        Citizen.CreateThread(function() 
            while CraftingTables[k].type ~= nil do
                CraftingTables[k].timer = CraftingTables[k].timer - 1
                if (CraftingTables[k].timer == 0) then
                    CraftingTables[k].crafting = false
                end 
                if (CraftingTables[k].timer <= -10) then
                    CraftingTables[k].crafting = false
                    CraftingTables[k].type = nil
                    CraftingTables[k].timer = 0
                    CraftingTables[k].fire = true
                    CraftingStartFire(k) 
                    break
                end 
                Citizen.Wait(1000)
            end
        end)
    end
end

function CraftingStartFire(k) 
    local craft = CraftingTables[k]
    local dict = "scr_trevor3"
    local particleName = "scr_trev3_trailer_plume"

    Citizen.CreateThread(function()
        RequestNamedPtfxAsset(dict)
        while not HasNamedPtfxAssetLoaded(dict) do
            Citizen.Wait(0)
        end
        UseParticleFxAssetNextCall(dict)
        CraftingTables[k].fire = StartParticleFxLoopedAtCoord(particleName, craft.coords.x, craft.coords.y, craft.coords.z, 0.0, 0.0, 0.0, 0.2, false, false, false)
    end)
end

function CraftingStopFire(k) 
    Citizen.CreateThread(function()
        AllowInteraction = false
        DisplayProgress(5000, "Extinguishing Fire", 'mini@repair', 'fixing_a_player')
        LoadAnim('mini@repair') 
        TaskPlayAnim(PlayerPedId(), 'mini@repair', 'fixing_a_player', 8.0, -8, -1, 49, 0, 0, 0, 0)
        Citizen.SetTimeout(5000, function()
            ClearPedTasksImmediately(PlayerPedId())
            StopParticleFxLooped(CraftingTables[k].fire, true)
            CraftingTables[k].fire = nil
            AllowInteraction = true
        end)
    end)
end

function GetCraft(k, type)
    local craft = CraftingTables[k]
    local items = craft.items
    for i=1, #items do 
        if (type == items[i].Name) then 
            return items[i], i
        end
    end
end

function GetCraftingText(k)
    local text = "|oven_status|"
    local craft = CraftingTables[k]
    if craft.crafting then 
        text = text:gsub("|oven_status|", "Crafting Timer: " .. craft.timer .. " second(s)")
    elseif craft.type ~= nil then
        text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to take out the ".. GetCraft(k, craft.type).Label ..".")
    elseif craft.fire then
        text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to extinguish the fire.")
    else
        text = text:gsub("|oven_status|", (craft.interact or "Press ~INPUT_CONTEXT~ to craft an item."))
    end
    return text
end

function InteractCraftingTable(k)
    local craft = CraftingTables[k]
    if craft.crafting then 
        -- Timer is active
    elseif craft.type ~= nil then
        -- Pickup Crafted Item
        PickupCraftedItem(k)
    elseif craft.fire then
        -- Extinguish Fire
        CraftingStopFire(k)
    else
        -- Show Crafting Menu
        ShowCraftingMenu(k)
    end
end

RegisterNetEvent("nh-context:returnData")
AddEventHandler("nh-context:returnData", function(_data)
    local key = _data.id
    local data = _data.data
    if (CraftingTables[key] ~= nil) then 
        ESX.TriggerServerCallback("esx_societyjob:startCrafting", function(result) 
            if not AllowInteraction then return end
            if (result) then 
                StartCrafting(key, data.selected)
            else
                ESX.ShowNotification("Missing Items for the Craft.")
            end
        end, key, data.selected)
    end
end)

Citizen.CreateThread(function()
    while true do 
        local cTables = CraftingTables
        local waitTimer = 1000
        local coords = GetEntityCoords(PlayerPedId())
        for k,v in pairs(cTables) do 
            local dist = #(v.coords - coords)
            if dist < 20.0 then 
                waitTimer = 0
                if (AllowInteraction and Marker(v.coords, dist, GetCraftingText(k))) then 
                    InteractCraftingTable(k)
                end
            end
        end
        Citizen.Wait(waitTimer)
    end
end)
