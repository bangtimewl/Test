Citizen.CreateThread(function()
    while true do
        local wait = 1000
        local coords = GetEntityCoords(PlayerPedId())
        for k, v in pairs(BossMenus) do 
            local dist = #(v.Coords - coords)
            if dist < 20.0 then 
                wait = 0
                if Marker(v.Coords, dist, "Press ~INPUT_CONTEXT~ to open the boss menu.") then 
                    -- Trigger the unified event for boss menu
                    TriggerServerEvent("esx_societyjob", "bossMenu")
                end
            end
        end
        Citizen.Wait(wait)
    end
end)
