ESX = exports["es_extended"]:getSharedObject()

-- Event to process part purchases for any job
RegisterNetEvent("esx_societyjob", function(action, ...)
    local args = { ... }
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end

    if action == "givePart" then
        local token = args[1]  -- (Optional security token)
        local storeKey = args[2]  -- e.g. "autoexotic_parts", "mechanic_parts", etc.
        local partName = args[3]

        -- Get the correct parts store from the global PartStores table (loaded from your config)
        local store = PartStores[storeKey]
        if not store then
            TriggerClientEvent('okokNotify:Alert', src, "Error", "Parts store not found.", 5000, 'error')
            return
        end

        -- If the store has a job requirement then only allow that job (if job == nil, then all can use)
        if store.job and xPlayer.job.name ~= store.job then
            TriggerClientEvent('okokNotify:Alert', src, "Error", "You are not authorized to use this parts store.", 5000, 'error')
            return
        end

        -- Find the requested part in the store's items
        local partData = nil
        for _, part in pairs(store.items) do
            if part.Name == partName then
                partData = part
                break
            end
        end

        if not partData then
            TriggerClientEvent('okokNotify:Alert', src, "Error", "Invalid part selection.", 5000, 'error')
            return
        end

        local price = partData.Price or 0
        local playerMoney = xPlayer.getAccount('money').money

        if playerMoney < price then
            TriggerClientEvent('okokNotify:Alert', src, "Error", "You don't have enough money.", 5000, 'error')
            return
        end

        -- Deduct money and add the item. Use the Amount field (defaults to 1 if not set)
        xPlayer.removeAccountMoney('money', price)
        local amount = partData.Amount or 1
        local success = exports.ox_inventory:AddItem(src, partData.Name, amount)
        if success then
            TriggerClientEvent('okokNotify:Alert', src, "Success", "You purchased " .. partData.Label .. " for $" .. price .. ".", 5000, 'success')
        else
            -- Refund if the item could not be added
            xPlayer.addAccountMoney('money', price)
            TriggerClientEvent('okokNotify:Alert', src, "Error", "Failed to add part. Money refunded.", 5000, 'error')
        end

    end
    -- (You can add additional actions here—for example, for billing—if needed)
end)

-- Callback for client-side check before purchase
ESX.RegisterServerCallback("esx_societyjob:purchasePart", function(source, cb, storeKey, partName)
    local xPlayer = ESX.GetPlayerFromId(source)
    local store = PartStores[storeKey]
    if not store then 
        cb(false)
        return 
    end

    local partData = nil
    for _, part in pairs(store.items) do
        if part.Name == partName then
            partData = part
            break
        end
    end

    if not partData then 
        cb(false)
        return 
    end

    local playerMoney = xPlayer.getAccount('money').money 
    if playerMoney < partData.Price then
        cb(false)
    else
        cb(true, "authorized_token")
    end
end)
