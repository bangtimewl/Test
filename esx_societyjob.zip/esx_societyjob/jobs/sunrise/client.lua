local JobData = Config.Jobs.Sunrise
local AllowInteraction = true
local CarryingData = {
    Active = false,
    EntityID = nil,
    Key = nil,
    Value = nil
}

function SunriseGetMarkerText(storeID, markerID) 
    local text = JobData.Shops[storeID].InteractMarkers[markerID].DisplayText
    if (key == "toggle_duty") then 
        text = text:gsub("|clocked_status|", (ClockedIn and "out" or "in"))
    end
    return text
end

function SunriseGetWorkbench2Submenu(index, SubData)
    local CurrentVehicle = GetLastDrivenVehicle(PlayerPedId())
    SetVehicleModKit(CurrentVehicle, 0)
    local parentData = JobData.VehicleParts2[index]
    local submenu = {
        {
            id = 1,
            header = SubData.Label,
            txt = "Choose a selection below."
        },
    }
    local modCount = GetNumVehicleMods(CurrentVehicle, parentData.ModType)
    if (parentData.ModType == 17) then 
        modCount = modCount + 1
    end
    for i = 0, modCount, 1 do
        submenu[#submenu + 1] = {
            id = i + 1,
            header = (i == 0 and "Default" or (parentData.Label .. " - Level " .. (i))),
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = SubData.Name,
                    data = {
                        selected = i - 1,
                    }
                }
            }
        }
    end
    submenu[#submenu + 1] = {
        id = #submenu + 1,
        header = "Back <<",
        txt = "",
        params = {
            event = "nh-context-bridge:returnData",
            args = {
                id = "returnWorkbench2",
                data = {
                    selected = "returnWorkbench2",
                }
            }
        }
    }
    return submenu
end

function SunriseGetWorkbench2Menu() 
    local menu = {
        {
            id = 1,
            header = "Vehicle Parts",
            txt = "This is where you can carry a vehicle part to the vehicle!"
        },
    }
    for i=1, #JobData.VehicleParts2 do 
        local submenu
        local data = JobData.VehicleParts2
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label .. " >>",
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "workbench2",
                    data = {
                        selected = data[i].Name,
                        submenu = data[i].ModType ~= nil and SunriseGetWorkbench2Submenu(i, data[i]) or nil,
                    }
                }
            }
        }
    end
    return menu
end

function SunriseInteractMarker(storeID, markerID)
    if (ESX.GetPlayerData().job.name ~= "sunrise") then 
        ESX.ShowNotification("You are not authorized to use this.")
        return
    end
    if (markerID == "workbench2") then 
        TriggerEvent('nh-context-bridge:sendMenu', SunriseGetWorkbench2Menu())
    elseif (markerID == "boss") then 
        OpenSocietyJobBossMenu()
    end
end

function SunriseThread()
    Citizen.CreateThread(function()
        while true do
            local wait = 1000
            local coords = GetPlayerCoords()
            for storeID, data in pairs(JobData.Shops) do 
                for markerID,markerData in pairs(data.InteractMarkers) do 
                    if (markerData.Display or markerData.Display == nil) then 
                        local dist = #(markerData.Coords - coords)
                        if (dist < 20.0) then 
                            wait = 0
                            if (Marker(markerData.Coords, dist, SunriseGetMarkerText(storeID, markerID)) and AllowInteraction) then 
                                SunriseInteractMarker(storeID, markerID)
                            end
                        end
                    end
                end
            end
            Citizen.Wait(wait)
        end
    end)
end

SunriseThread()

function StopCarrying()
    CarryingData.Key = nil
    CarryingData.Value = nil
    DestroyAllProps()
    ClearPedTasksImmediately(PlayerPedId())    
end

function UpgradeVehicle(vehicle)
    local CurrentMods = ESX.Game.GetVehicleProperties(vehicle)
    CurrentMods[CarryingData.Key] = CarryingData.Value
    ESX.Game.SetVehicleProperties(vehicle, CurrentMods)
    TriggerServerEvent("esx_societyjobs:sunrise:updateVehicle", CurrentMods)

    StopCarrying()
end

function SetActiveCarrying(key, index)
    OnEmotePlay(JobData.CarryingSettings[key])
    CarryingData.Key = key
    CarryingData.Value = index

    Citizen.CreateThread(function() 
        while key == CarryingData.Key and index == CarryingData.Value do 
            if (IsControlJustPressed(1, 51)) then 
                local CurrentVehicle = GetLastDrivenVehicle(PlayerPedId())
                if #(GetEntityCoords(CurrentVehicle) - GetEntityCoords(PlayerPedId())) < 3.0 then 
                    FreezeEntityPosition(PlayerPedId(), true)
                    if (CarryingData.Key == "repair") then 
                        SetVehicleEngineHealth(CurrentVehicle, 100)
                        SetVehicleEngineOn(CurrentVehicle, true, true)
                        SetVehicleFixed(CurrentVehicle)
                    else
                        UpgradeVehicle(CurrentVehicle)
                    end

                    Citizen.Wait(100)
     
                    OnEmotePlay(Config.Emotes["mechanic"])
                    DisplayProgress(15000, "Installing", 'mini@repair', 'fixing_a_player')
                    Citizen.Wait(15000)

                    ClearPedTasksImmediately(PlayerPedId())    

                    FreezeEntityPosition(PlayerPedId(), false)
                    break
                end
            elseif (IsControlJustPressed(1, 73)) then
                StopCarrying() 
                break
            end
            Citizen.Wait(0)
        end
    end)
end

RegisterNetEvent("nh-context:returnData")
AddEventHandler("nh-context:returnData", function(_data)
    local key = _data.id
    local data = _data.data
    if (key == "workbench2") then 
        if (data.selected == "repair") then 
            SetActiveCarrying(data.selected, 0)
        else 
            TriggerEvent('nh-context-bridge:sendMenu', data.submenu)
        end
    elseif (JobData.CarryingSettings[key]) then 
        SetActiveCarrying(key, data.selected)
    elseif (key == "returnWorkbench2") then 
        TriggerEvent('nh-context-bridge:sendMenu', SunriseGetWorkbench2Menu())
    end
end)