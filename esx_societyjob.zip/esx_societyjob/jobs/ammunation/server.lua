ESX = exports["es_extended"]:getSharedObject()

------------------------------------------------
-- HELPER FUNCTION: Remove required ingredients
------------------------------------------------
local function removeRequiredIngredients(source, jobKey, itemName)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then
        print("[Ammunation] removeRequiredIngredients: invalid player")
        return false, "Player not found"
    end

    local jobConfig = Config.Jobs[jobKey]
    if not jobConfig then
        print("[Ammunation] removeRequiredIngredients: job config not found for " .. jobKey)
        return false, "Job config not found"
    end

    -- Find the item in the CookableItems list
    local itemData = nil
    for _, v in ipairs(jobConfig.CookableItems) do
        if v.Name == itemName then
            itemData = v
            break
        end
    end

    if not itemData then
        print("[Ammunation] removeRequiredIngredients: item " .. itemName .. " not found in CookableItems")
        return false, "Item not found"
    end

    if not itemData.RequiredIngredients then
        -- No ingredients required
        return true
    end

    -- Check if the player has at least one of each required ingredient
    for _, ingredient in ipairs(itemData.RequiredIngredients) do
        local count = exports.ox_inventory:GetItemCount(source, ingredient)
        if count < 1 then
            return false, ("Missing ingredient: %s"):format(ingredient)
        end
    end

    -- Remove one unit of each required ingredient
    for _, ingredient in ipairs(itemData.RequiredIngredients) do
        local removed = exports.ox_inventory:RemoveItem(source, ingredient, 1)
        if not removed then
            return false, ("Failed to remove ingredient: %s"):format(ingredient)
        end
    end

    return true
end

------------------------------------------------
-- CALLBACK: Start Crafting (remove ingredients)
------------------------------------------------
ESX.RegisterServerCallback("esx_societyjobs:ammunation:bakeAmmunation", function(source, cb, itemName)
    local success, err = removeRequiredIngredients(source, "Ammunation", itemName)
    if success then
        cb(itemName)
    else
        cb(false)
        TriggerClientEvent('okokNotify:Alert', source, "Error", err or "Missing ingredients", 5000, 'error')
    end
end)

------------------------------------------------
-- EVENT: Finish Crafting (give crafted item to player)
------------------------------------------------
RegisterNetEvent("esx_societyjobs:ammunation:cookedAmmunation")
AddEventHandler("esx_societyjobs:ammunation:cookedAmmunation", function(itemName)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end

    local jobConfig = Config.Jobs.Ammunation
    if not jobConfig or not jobConfig.CookableItems then
        TriggerClientEvent('okokNotify:Alert', src, "Error", "Job config or CookableItems missing", 5000, 'error')
        return
    end

    local itemData = nil
    for _, v in ipairs(jobConfig.CookableItems) do
        if v.Name == itemName then
            itemData = v
            break
        end
    end

    if not itemData then
        TriggerClientEvent('okokNotify:Alert', src, "Error", "Invalid crafted item", 5000, 'error')
        return
    end

    if itemData.Type == "weapon" then
        -- For weapons, add them using addWeapon with a default ammo amount (adjust as needed)
        xPlayer.addWeapon(itemName, 50)
        TriggerClientEvent('okokNotify:Alert', src, "Success", "You crafted a " .. (itemData.Label or itemName), 5000, 'success')
    else
        -- For non-weapon items, simply use addInventoryItem.
        xPlayer.addInventoryItem(itemName, 1)
        TriggerClientEvent('okokNotify:Alert', src, "Success", "You crafted a " .. (itemData.Label or itemName), 5000, 'success')
    end
end)

------------------------------------------------
-- CALLBACK: Purchase Ingredient for Ammunation
------------------------------------------------
ESX.RegisterServerCallback("esx_societyjobs:ammunation:purchaseIngredient", function(source, cb, ingredientName)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then
        cb(false)
        return
    end

    local jobConfig = Config.Jobs.Ammunation
    if not jobConfig or not jobConfig.Ingredients then
        cb(false)
        return
    end

    local ingredientData = nil
    for _, v in ipairs(jobConfig.Ingredients) do
        if v.Name == ingredientName then
            ingredientData = v
            break
        end
    end

    if not ingredientData then
        cb(false)
        return
    end

    local price = ingredientData.Price or 0
    local cash = xPlayer.getMoney()

    if cash < price then
        cb(false)
    else
        xPlayer.removeMoney(price)
        local success = exports.ox_inventory:AddItem(source, ingredientName, 1)
        if success then
            TriggerClientEvent('okokNotify:Alert', source, "Success", ("You purchased %s for $%d"):format(ingredientData.Label, price), 5000, 'success')
            cb(true)
        else
            xPlayer.addMoney(price)  -- Refund money if item addition fails
            TriggerClientEvent('okokNotify:Alert', source, "Error", "Failed to add ingredient. Money refunded.", 5000, 'error')
            cb(false)
        end
    end
end)
