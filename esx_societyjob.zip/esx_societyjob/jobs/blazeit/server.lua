ESX = exports["es_extended"]:getSharedObject()

RegisterNetEvent('blazeit_giveReward', function()
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if xPlayer then
        local item = 'money' -- Change this to the reward item
        local amount = 100 -- Adjust the amount as needed
        exports.ox_inventory:AddItem(item, amount)
        TriggerClientEvent('okokNotify:Alert', src, "Success", "You received " .. amount .. " " .. item, 5000, 'success')
    end
end)

RegisterNetEvent('blazeit_removeItem', function(item, amount)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if xPlayer and exports.ox_inventory:GetItem(source, item)?.count or 0 >= amount then
        exports.ox_inventory:RemoveItem(item, amount)
        TriggerClientEvent('okokNotify:Alert', src, "Success", "You used " .. amount .. " " .. item, 5000, 'success')
    else
        TriggerClientEvent('okokNotify:Alert', src, "Error", "Not enough " .. item, 5000, 'error')
    end
end)

ESX.RegisterServerCallback('blazeit_checkItem', function(source, cb, item, amount)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer then
        local hasItem = xPlayer.getInventoryItem(item)
        if hasItem and hasItem.count >= amount then
            cb(true)
        else
            cb(false)
        end
    else
        cb(false)
    end
end)


-- Register missing callback: purchaseIngredient with improved validation


-- Register missing callback: purchaseIngredient with proper item removal


-- Register missing callback: purchaseIngredient with proper item removal and improved money check


-- Register missing callback: purchaseIngredient with deep debugging


-- Register missing callback: purchaseIngredient with proper item removal fix


-- Register missing callback: purchaseIngredient with ox_inventory item removal fix


-- Register missing callback: purchaseIngredient with ox_inventory integration
ESX.RegisterServerCallback('esx_societyjobs:ammunation:purchaseIngredient', function(source, cb, itemName, amount)
    local xPlayer = ESX.GetPlayerFromId(source)

    -- Ensure valid item and amount
    if not xPlayer or not itemName or not tonumber(amount) or tonumber(amount) <= 0 then
        print("[DEBUG] Invalid item or amount passed.")
        cb(false)
        return
    end

    amount = tonumber(amount)  -- Convert amount to number
    local itemPrice = 4  -- Adjust based on your config
    local totalPrice = itemPrice * amount

    -- Debug: Print player's cash and bank money
    local cash = xPlayer.getMoney()
    local bank = xPlayer.getAccount('bank').money

    print("[DEBUG] Player Cash: " .. cash .. " | Bank: " .. bank .. " | Required: " .. totalPrice)

    if cash >= totalPrice then
        local itemData = exports.ox_inventory:GetItem(source, itemName)

        if itemData and itemData.count >= amount then
            -- Debug: Confirm item exists before removal
            print("[DEBUG] Player has " .. itemData.count .. " of " .. itemName .. " - Attempting to remove " .. amount)

            xPlayer.removeMoney(totalPrice) -- Remove money first
            
            local success = exports.ox_inventory:RemoveItem(source, itemName, amount)

            -- Check if removal was successful
            if success then
                print("[DEBUG] Successfully removed " .. amount .. " of " .. itemName)
                cb(true)
            else
                print("[DEBUG] Failed to remove " .. amount .. " of " .. itemName)
                TriggerClientEvent('okokNotify:Alert', source, 'Error', 'Item removal failed!', 5000, 'error')
                cb(false)
            end
        else
            print("[DEBUG] Player does not have enough " .. itemName)
            TriggerClientEvent('okokNotify:Alert', source, 'Error', 'Not enough ' .. itemName .. '!', 5000, 'error')
            cb(false)
        end
    else
        print("[DEBUG] Player cannot afford this purchase. Cash: " .. cash .. " | Required: " .. totalPrice)
        TriggerClientEvent('okokNotify:Alert', source, 'Error', 'Not enough money!', 5000, 'error')
        cb(false)
    end
end)

-- Register missing callback: getClosestPlayers
ESX.RegisterServerCallback('esx_societyjobs:billing:getClosestPlayers', function(source, cb)
    local xPlayers = ESX.GetExtendedPlayers()
    local players = {}

    for _, xPlayer in pairs(xPlayers) do
        if xPlayer.source ~= source then
            table.insert(players, {id = xPlayer.source, name = xPlayer.getName()})
        end
    end

    cb(players)
end)
