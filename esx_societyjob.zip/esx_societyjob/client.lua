ESX = nil
PlayerData = nil

PlayerProps = {}
PlayerHasProp = false

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end
    PlayerData = ESX.GetPlayerData()
    TriggerEvent("esx_societyjob:jobUpdated", PlayerData.job)
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
    TriggerEvent("esx_societyjob:jobUpdated", PlayerData.job)
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
    PlayerData.job = job
    TriggerEvent("esx_societyjob:jobUpdated", PlayerData.job)
end)

RegisterNetEvent('esx_societyjob:jobUpdated')
AddEventHandler('esx_societyjob:jobUpdated', function(job)
    -- You can add additional logic here when a job is updated.
end)

RegisterNetEvent('esx_societyjobs:usedItem')
AddEventHandler('esx_societyjobs:usedItem', function(name)
    if (Config.UsableItems[name]) then 
        Config.UsableItems[name].client(function(result)
            -- Additional logic after using an item (if needed).
        end)
    end
end)

function GetPlayerCoords(id)
    return GetEntityCoords(not id and PlayerPedId() or GetPlayerPed(GetPlayerFromServerId(id)))
end

function Draw3DText(coords, text)
    local str = text
    
    local start, stop = string.find(text, "~([^~]+)~")
    if start then
        start = start - 2
        stop = stop + 2
        str = ""
        str = str .. string.sub(text, 0, start) .. "   " .. string.sub(text, start+2, stop-2) .. string.sub(text, stop, #text)
    end

    AddTextEntry(GetCurrentResourceName(), str)
    BeginTextCommandDisplayHelp(GetCurrentResourceName())
    EndTextCommandDisplayHelp(2, false, false, -1)

    SetFloatingHelpTextWorldPosition(1, coords)
    SetFloatingHelpTextStyle(1, 1, 2, -1, 3, 0)
end

function Marker(coords, dist, text)
    if (dist < 1.0) then 
        Draw3DText(vector3(coords.x, coords.y, coords.z + 0.4), text)
    end
    DrawMarker(20, coords.x, coords.y, coords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5, 0.5, 0.5, 31, 94, 255, 100, false, true, false, false, nil, nil, false)
    if (IsControlJustPressed(1, 51) and dist < 1.0) then
        return true
    end
end

function DisplayProgress(time, label, scenario, dictionary)
    exports.rprogress:Custom({
        Duration = time,
        Label = label,
        Animation = {
            animationName = scenario,
            animationDictionary = dictionary,
        },
        DisableControls = {
            Mouse = false,
            Player = true,
            Vehicle = true
        }
    })
end

function DestroyAllProps()
    for _,v in pairs(PlayerProps) do
      DeleteEntity(v)
    end
    PlayerHasProp = false
end

function OnEmotePlay(EmoteName)
    local ChosenDict, ChosenAnimation, ename = table.unpack(EmoteName)
    local AnimationDuration = -1

    if PlayerHasProp then
      DestroyAllProps()
      Wait(200)
    end

    if not LoadAnim(ChosenDict) then
      return
    end

    local MovementType = 0
    if EmoteName.AnimationOptions then
        if EmoteName.AnimationOptions.EmoteLoop then
            MovementType = 1
            if EmoteName.AnimationOptions.EmoteMoving then
                MovementType = 51
            end
        elseif EmoteName.AnimationOptions.EmoteMoving then
            MovementType = 51
        elseif EmoteName.AnimationOptions.EmoteStuck then
            MovementType = 50
        end
    end

    if InVehicle == 1 then
      MovementType = 51
    end

    if EmoteName.AnimationOptions then
        if EmoteName.AnimationOptions.EmoteDuration == nil then
            EmoteName.AnimationOptions.EmoteDuration = -1
            AttachWait = 0
        else
            AnimationDuration = EmoteName.AnimationOptions.EmoteDuration
            AttachWait = EmoteName.AnimationOptions.EmoteDuration
        end
    end

    TaskPlayAnim(GetPlayerPed(-1), ChosenDict, ChosenAnimation, 2.0, 2.0, AnimationDuration, MovementType, 0, false, false, false)
    RemoveAnimDict(ChosenDict)
    IsInAnimation = true
    MostRecentDict = ChosenDict
    MostRecentAnimation = ChosenAnimation

    if EmoteName.AnimationOptions and EmoteName.AnimationOptions.Prop then
          local PropName = EmoteName.AnimationOptions.Prop
          local PropBone = EmoteName.AnimationOptions.PropBone
          local PropPl1, PropPl2, PropPl3, PropPl4, PropPl5, PropPl6 = table.unpack(EmoteName.AnimationOptions.PropPlacement)
          local SecondPropEmote = false
          if EmoteName.AnimationOptions.SecondProp then
            SecondPropEmote = true
            local SecondPropName = EmoteName.AnimationOptions.SecondProp
            local SecondPropBone = EmoteName.AnimationOptions.SecondPropBone
            local SecondPropPl1, SecondPropPl2, SecondPropPl3, SecondPropPl4, SecondPropPl5, SecondPropPl6 = table.unpack(EmoteName.AnimationOptions.SecondPropPlacement)
            Wait(AttachWait)
            AddPropToPlayer(PropName, PropBone, PropPl1, PropPl2, PropPl3, PropPl4, PropPl5, PropPl6)
            AddPropToPlayer(SecondPropName, SecondPropBone, SecondPropPl1, SecondPropPl2, SecondPropPl3, SecondPropPl4, SecondPropPl5, SecondPropPl6)
          else
            Wait(AttachWait)
            AddPropToPlayer(PropName, PropBone, PropPl1, PropPl2, PropPl3, PropPl4, PropPl5, PropPl6)
          end
    end

    if EmoteName.AnimationOptions and EmoteName.AnimationOptions.AdditionalProps then
      for i = 1, #EmoteName.AnimationOptions.AdditionalProps do 
        local propSettings = EmoteName.AnimationOptions.AdditionalProps[i]
        local PropPl1, PropPl2, PropPl3, PropPl4, PropPl5, PropPl6 = table.unpack(propSettings.PropPlacement)
        AddPropToPlayer(propSettings.Prop, propSettings.PropBone, PropPl1, PropPl2, PropPl3, PropPl4, PropPl5, PropPl6)
      end
    end
    return true
end

function AddPropToPlayer(prop1, bone, off1, off2, off3, rot1, rot2, rot3)
    local Player = PlayerPedId()
    local x, y, z = table.unpack(GetEntityCoords(Player))

    if not HasModelLoaded(prop1) then
      if not LoadPropDict(prop1) then
        return
      end
    end

    local prop = CreateObject(GetHashKey(prop1), x, y, z + 0.2, true, true, true)
    AttachEntityToEntity(prop, Player, GetPedBoneIndex(Player, bone), off1, off2, off3, rot1, rot2, rot3, true, true, false, true, 1, true)
    table.insert(PlayerProps, prop)
    PlayerHasProp = true
    SetModelAsNoLongerNeeded(prop1)
end

function LoadAnim(dict)
    local timeout = 1000
    while not HasAnimDictLoaded(dict) do
        RequestAnimDict(dict)
        timeout = timeout - 5
        if timeout <= 0 then
            break
        end
        Citizen.Wait(5)
    end
    return HasAnimDictLoaded(dict)
end

function LoadPropDict(model)
    local timeout = 1000
    while not HasModelLoaded(GetHashKey(model)) do
        RequestModel(GetHashKey(model))
        timeout = timeout - 10
        if timeout <= 0 then
            break
        end
        Wait(10)
    end
    return HasModelLoaded(GetHashKey(model))
end

function OnScriptStarted(cb)
    Citizen.CreateThread(function()
        while ESX.GetPlayerData().job == nil do
            Citizen.Wait(0)
        end
        cb()
    end)
end

function OpenSocietyJobBossMenu()
    if ESX.GetPlayerData().job.grade_name ~= "boss" then return end
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'cloakroom', {
        title    = PlayerData.job.label .. " - Office",
        align    = 'bottom-right',
        elements = {
            {label = "Manage Business", value = "management"},
            {label = "Access Inventory", value = "inventory"},
        }
    }, function(data, menu)
        if data.current.value == "management" then
            TriggerEvent('esx_society:openBossMenu', PlayerData.job.name, function(data, menu)
                menu.close()
            end)
        elseif data.current.value == "inventory" then
            local stashID = 'society_' .. PlayerData.job.name
            local ownerID = nil
            exports.ox_inventory:openInventory('stash', {id = stashID, owner = ownerID})
        end
    end, function(data, menu)
        menu.close()
    end)
end
