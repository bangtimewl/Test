shared_script "@ReaperV4/bypass.lua"
lua54 "yes" -- needed for Reaper

shared_scripts { '@FiniAC/fini_events.lua' }

fx_version 'cerulean'
game 'gta5'

version '1.0'

shared_scripts {
    "@ox_lib/init.lua",
    "config.lua",
}

client_script {
    'client.lua',
    'nui.lua',
    'modules/menu/bridge_cl.lua',
    'modules/npc/npc_cl.lua',
    'modules/crafting/crafting_cl.lua',
    'modules/parts/parts_cl.lua',
    'modules/billing/billing_cl.lua',
    'modules/boss/boss_cl.lua',
    'modules/outfits/outfits_cl.lua',
    'jobs/autoexotic/client.lua',
    'jobs/lawyer/client.lua',
    'jobs/bahama/client.lua',
    'jobs/denaros/client.lua',
    'jobs/bishops/client.lua',
    'jobs/dunkin/client.lua',
    'jobs/barber/client.lua',
    'jobs/nailspa/client.lua',
    'jobs/mechanic/client.lua',
    'jobs/sunrise/client.lua',
    'jobs/ammunation/client.lua',
    'jobs/burgershot/client.lua',
    'jobs/bennys/client.lua',
    'jobs/pitstop/client.lua',
    'jobs/catcafe/client.lua',
    'jobs/hayes/client.lua',
    'jobs/blazeit/client.lua',
    'jobs/pearls/client.lua',
    'jobs/mosleys/client.lua',
    'jobs/showcase/client.lua',
    'jobs/showcasezaza/client.lua',
    'jobs/showcasesmokeys/client.lua',	
}

server_script {
    '@mysql-async/lib/MySQL.lua',
    'server.lua',
    'modules/crafting/crafting_sv.lua',
    'modules/parts/parts_sv.lua',
    'modules/billing/billing_sv.lua',
    'jobs/autoexotic/server.lua',
    'jobs/bahama/server.lua',
    'jobs/denaros/server.lua',
    'jobs/bishops/server.lua',
    'jobs/dunkin/server.lua',
    'jobs/barber/server.lua',
    'jobs/nailspa/server.lua',
    'jobs/mechanic/server.lua',
    'jobs/sunrise/server.lua',
    'jobs/ammunation/server.lua',
    'jobs/burgershot/server.lua',
    'jobs/bennys/server.lua',
    'jobs/pitstop/server.lua',
    'jobs/catcafe/server.lua',
    'jobs/hayes/server.lua',
    'jobs/blazeit/server.lua',
    'jobs/pearls/server.lua',
    'jobs/mosleys/server.lua',
    'jobs/showcase/server.lua',
    'jobs/showcasezaza/server.lua',
    'jobs/showcasesmokeys/server.lua',	
}

files {
    "ui/index.html",
    "ui/*.css",
    "ui/*.js",
    "ui/assets/*.js",
    "ui/assets/*.css",
    "ui/images/**/*"
}

ui_page "ui/index.html"

lua54 'yes'
